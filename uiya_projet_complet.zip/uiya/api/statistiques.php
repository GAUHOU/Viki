<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('administrateur','responsable');

$db = getDB();
$action = $_GET['action'] ?? 'global';

switch ($action) {

    // Stats globales pour le dashboard admin
    case 'global':
        $stats = [];
        $stats['nb_etudiants']  = $db->query("SELECT COUNT(*) FROM etudiant")->fetchColumn();
        $stats['nb_enseignants']= $db->query("SELECT COUNT(*) FROM enseignant")->fetchColumn();
        $stats['nb_filieres']   = $db->query("SELECT COUNT(*) FROM filiere")->fetchColumn();
        $stats['nb_classes']    = $db->query("SELECT COUNT(*) FROM classe")->fetchColumn();
        $stats['nb_cours']      = $db->query("SELECT COUNT(*) FROM cours")->fetchColumn();
        $stats['nb_parents']    = $db->query("SELECT COUNT(*) FROM parent")->fetchColumn();
        $stats['nb_absences']   = $db->query("SELECT COUNT(*) FROM presence WHERE statut='absent'")->fetchColumn();
        $stats['nb_non_justif'] = $db->query("SELECT COUNT(*) FROM presence WHERE statut='absent' AND justifiee=0")->fetchColumn();
        jsonResponse(['success'=>true,'data'=>$stats]);

    // Inscriptions par filière
    case 'etudiants_par_filiere':
        $stmt=$db->query("SELECT f.nom_filiere,f.code_filiere,
                                 COUNT(e.id_ed) AS nb_etudiants
                          FROM filiere f
                          LEFT JOIN classe c ON c.id_filiere=f.id_filiere
                          LEFT JOIN etudiant e ON e.id_cl=c.id_cl
                          GROUP BY f.id_filiere,f.nom_filiere,f.code_filiere
                          ORDER BY nb_etudiants DESC");
        jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);

    // Moyennes par matière
    case 'moyennes_par_cours':
        $classeId = $_GET['id_cl'] ?? null;
        $sql="SELECT co.matiere,co.intitule,
                     ROUND(AVG(n.valeur),2) AS moyenne,
                     COUNT(n.idnote) AS nb_notes,
                     MIN(n.valeur) AS note_min,
                     MAX(n.valeur) AS note_max
              FROM note n JOIN cours co ON co.idcours=n.idcours
              JOIN etudiant e ON e.id_ed=n.id_ed";
        $params=[];
        if ($classeId) { $sql.=" WHERE e.id_cl=?"; $params[]=$classeId; }
        $sql.=" GROUP BY co.idcours,co.matiere,co.intitule ORDER BY moyenne DESC";
        $stmt=$db->prepare($sql); $stmt->execute($params);
        jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);

    // Absences par mois
    case 'absences_par_mois':
        $stmt=$db->query("SELECT DATE_FORMAT(datepresence,'%Y-%m') AS mois,
                                 MONTHNAME(datepresence) AS nom_mois,
                                 COUNT(*) AS nb_absences,
                                 SUM(justifiee) AS nb_justifiees
                          FROM presence WHERE statut='absent'
                          GROUP BY mois ORDER BY mois DESC LIMIT 6");
        jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);

    // Taux de réussite par filière
    case 'reussite_par_filiere':
        $stmt=$db->query("SELECT f.nom_filiere,f.code_filiere,
                                 COUNT(DISTINCT e.id_ed) AS nb_etudiants,
                                 ROUND(AVG(
                                     (SELECT SUM(n.valeur*n.coefficient)/SUM(n.coefficient)
                                      FROM note n WHERE n.id_ed=e.id_ed)
                                 ),2) AS moyenne_filiere,
                                 SUM(CASE WHEN
                                     (SELECT SUM(n.valeur*n.coefficient)/SUM(n.coefficient)
                                      FROM note n WHERE n.id_ed=e.id_ed) >= 10
                                     THEN 1 ELSE 0 END) AS nb_admis
                          FROM filiere f
                          LEFT JOIN classe c ON c.id_filiere=f.id_filiere
                          LEFT JOIN etudiant e ON e.id_cl=c.id_cl
                          GROUP BY f.id_filiere HAVING nb_etudiants>0");
        $data=$stmt->fetchAll();
        foreach ($data as &$row) {
            $row['taux_reussite'] = $row['nb_etudiants']>0
                ? round(($row['nb_admis']/$row['nb_etudiants'])*100,1) : 0;
        }
        jsonResponse(['success'=>true,'data'=>$data]);

    // Bulletin complet d'un étudiant
    case 'bulletin':
        $etuId=(int)($_GET['id_ed']??0); $trimestre=$_GET['trimestre']??null;
        if (!$etuId) jsonResponse(['success'=>false,'message'=>'ID étudiant requis'],400);

        // Infos étudiant
        $stmt=$db->prepare("SELECT e.*,CONCAT(u.nom,' ',u.prenoms) AS nom_complet,u.genre,
                                    c.nom_cl,f.nom_filiere,f.niveau
                            FROM etudiant e
                            JOIN utilisateur u ON u.id_utilisateur=e.id_utilisateur
                            JOIN classe c ON c.id_cl=e.id_cl
                            JOIN filiere f ON f.id_filiere=c.id_filiere
                            WHERE e.id_ed=?");
        $stmt->execute([$etuId]); $etudiant=$stmt->fetch();
        if (!$etudiant) jsonResponse(['success'=>false,'message'=>'Étudiant introuvable'],404);

        // Notes
        $sql="SELECT n.*,co.matiere,co.intitule,
                     CONCAT(u.nom,' ',u.prenoms) AS nom_enseignant
              FROM note n JOIN cours co ON co.idcours=n.idcours
              JOIN enseignant en ON en.id_ens=co.id_ens
              JOIN utilisateur u ON u.id_utilisateur=en.id_utilisateur
              WHERE n.id_ed=?";
        $params=[$etuId];
        if ($trimestre) { $sql.=" AND n.trimestre=?"; $params[]=$trimestre; }
        $sql.=" ORDER BY co.matiere";
        $stmt=$db->prepare($sql); $stmt->execute($params); $notes=$stmt->fetchAll();

        // Calcul moyenne générale
        $totalPond=0; $totalCoeff=0;
        foreach ($notes as &$n) {
            $totalPond+=$n['valeur']*$n['coefficient']; $totalCoeff+=$n['coefficient'];
            if (!$n['appreciation']) $v=$n['valeur']>=16?'Très Bien':($v=$n['valeur']>=14?'Bien':($n['valeur']>=12?'Assez Bien':($n['valeur']>=10?'Passable':'Insuffisant')));
        }
        $moyenne=$totalCoeff>0?round($totalPond/$totalCoeff,2):0;
        $mention=$moyenne>=16?'Très Bien':($moyenne>=14?'Bien':($moyenne>=12?'Assez Bien':($moyenne>=10?'Passable':'Insuffisant')));

        // Classement
        $stmt=$db->prepare("SELECT e2.id_ed,
                                   SUM(n2.valeur*n2.coefficient)/SUM(n2.coefficient) AS moy
                            FROM etudiant e2 JOIN note n2 ON n2.id_ed=e2.id_ed
                            WHERE e2.id_cl=(SELECT id_cl FROM etudiant WHERE id_ed=?)
                            GROUP BY e2.id_ed ORDER BY moy DESC");
        $stmt->execute([$etuId]); $classement=$stmt->fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_UNIQUE,0);
        $rang=array_search($etuId,array_keys($classement))+1;

        jsonResponse(['success'=>true,'data'=>[
            'etudiant'=>$etudiant,'notes'=>$notes,
            'moyenne'=>$moyenne,'mention'=>$mention,'rang'=>$rang,'total_coeff'=>$totalCoeff
        ]]);

    default:
        jsonResponse(['success'=>false,'message'=>'Action inconnue'],400);
}
?>
