<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>UIYA — Espace Parent</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-icon">U</div><div class="logo-text"><div class="name">UIYA</div><div class="sub">Espace Parent</div></div></div>
  <div class="sidebar-user">
    <div class="user-avatar" style="background:linear-gradient(135deg,#f97316,#D4AF37);">K</div>
    <div class="user-info"><div class="user-name">KANGA Arsène</div><div class="user-role" style="color:#f97316;">Parent · YAO Adjoua</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-title">Suivi de mon enfant</div>
    <a class="nav-item active" data-page="dashboard" onclick="showPage('dashboard')"><span class="icon">🏠</span> Tableau de bord</a>
    <a class="nav-item" data-page="notes" onclick="showPage('notes')"><span class="icon">📝</span> Notes & Bulletins</a>
    <a class="nav-item" data-page="emplois" onclick="showPage('emplois')"><span class="icon">📅</span> Emploi du temps</a>
    <a class="nav-item" data-page="absences" onclick="showPage('absences')"><span class="icon">📋</span> Absences</a>
    <a class="nav-item" data-page="infos" onclick="showPage('infos')"><span class="icon">📢</span> Informations</a>
  </nav>
  <div class="sidebar-footer"><a class="nav-item" href="../index.html"><span class="icon">🚪</span> Déconnexion</a></div>
</aside>

<div class="main-content">
  <header class="topbar">
    <div class="topbar-left">
      <button class="topbar-btn hamburger" onclick="toggleSidebar()">☰</button>
      <div><div class="topbar-title" id="pageTitle">Tableau de bord</div><div class="topbar-subtitle">Suivi de YAO Adjoua Victoire</div></div>
    </div>
    <div class="topbar-right"><a class="topbar-btn">🔔</a><a class="topbar-btn" href="../index.html">🚪</a></div>
  </header>

  <div class="page-content">

    <!-- DASHBOARD -->
    <div id="page-dashboard">
      <!-- Profile card -->
      <div class="card mb-20" style="background:linear-gradient(135deg,rgba(139,26,26,0.15),rgba(212,175,55,0.08));border-color:rgba(212,175,55,0.2);">
        <div class="card-body" style="display:flex;align-items:center;gap:20px;">
          <div style="width:72px;height:72px;border-radius:16px;background:linear-gradient(135deg,#3b82f6,#22c55e);display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;color:white;flex-shrink:0;">Y</div>
          <div style="flex:1;">
            <div style="font-family:Playfair Display,serif;font-size:20px;font-weight:700;">YAO Adjoua Victoire</div>
            <div style="color:var(--text-muted);font-size:13px;margin-top:4px;">🎓 Licence 3 Génie Logiciel · Classe GL3-A</div>
            <div style="color:var(--text-muted);font-size:13px;">📌 Matricule: UIYA-2021-GL-004 · Année: 2020-2021</div>
          </div>
          <div style="text-align:center;padding:12px 20px;background:rgba(212,175,55,0.1);border-radius:12px;border:1px solid rgba(212,175,55,0.2);">
            <div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#D4AF37;">14.2</div>
            <div style="font-size:12px;color:var(--text-muted);">Moyenne /20</div>
            <div style="font-size:11px;color:#22c55e;margin-top:4px;">✓ Admis</div>
          </div>
        </div>
      </div>

      <div class="stats-grid">
        <div class="stat-card"><div class="stat-icon">🏆</div><div class="stat-value" style="color:#D4AF37;">3ème</div><div class="stat-label">Classement</div><div class="stat-change up">sur 25 élèves</div></div>
        <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value" style="font-size:24px;color:#22c55e;">96%</div><div class="stat-label">Présence</div><div class="stat-change up">↑ Excellent</div></div>
        <div class="stat-card"><div class="stat-icon">❌</div><div class="stat-value" style="font-size:24px;color:#ef4444;">2</div><div class="stat-label">Absences</div><div class="stat-change neutral">1 justifiée</div></div>
        <div class="stat-card"><div class="stat-icon">📚</div><div class="stat-value" data-counter="6">6</div><div class="stat-label">Matières</div><div class="stat-change neutral">T1 · 2021</div></div>
      </div>

      <div class="grid-2 mt-20" style="margin-top:20px;">
        <div class="card">
          <div class="card-header"><span class="card-title">📊 Notes par matière</span></div>
          <div class="card-body"><canvas id="chartParent" style="width:100%;height:200px;display:block;"></canvas></div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title">📢 Dernières annonces</span></div>
          <div class="card-body" id="annonceParent"></div>
        </div>
      </div>
    </div>

    <!-- NOTES -->
    <div id="page-notes" style="display:none;">
      <div class="topbar-title mb-20">Notes & Bulletins de YAO Adjoua</div>
      <div class="card mb-20">
        <div class="card-body" style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;text-align:center;">
          <div><div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#D4AF37;">14.2</div><div style="font-size:12px;color:var(--text-muted);">Moyenne T1</div></div>
          <div><div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#22c55e;">3ème</div><div style="font-size:12px;color:var(--text-muted);">Classement</div></div>
          <div><div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#3b82f6;">Bien</div><div style="font-size:12px;color:var(--text-muted);">Mention</div></div>
          <div><div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#22c55e;">✓</div><div style="font-size:12px;color:var(--text-muted);">Admis</div></div>
        </div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Matière</th><th>Note /20</th><th>Coeff.</th><th>Pondéré</th><th>Appréciation</th></tr></thead>
            <tbody>
              <tr><td>Base de Données</td><td style="font-weight:700;color:#22c55e;">14.5</td><td>3</td><td>43.5</td><td><span class="badge badge-success">Assez Bien</span></td></tr>
              <tr><td>Développement Web PHP</td><td style="font-weight:700;color:#22c55e;">16</td><td>2</td><td>32</td><td><span class="badge badge-success">Bien</span></td></tr>
              <tr><td>UML & Modélisation</td><td style="font-weight:700;color:#eab308;">13</td><td>3</td><td>39</td><td><span class="badge badge-warning">Assez Bien</span></td></tr>
              <tr><td>Algorithmique</td><td style="font-weight:700;color:#eab308;">12</td><td>2</td><td>24</td><td><span class="badge badge-warning">Passable</span></td></tr>
              <tr><td>Réseaux informatiques</td><td style="font-weight:700;color:#22c55e;">15</td><td>2</td><td>30</td><td><span class="badge badge-success">Bien</span></td></tr>
              <tr><td>Anglais des affaires</td><td style="font-weight:700;color:#22c55e;">17</td><td>1</td><td>17</td><td><span class="badge badge-success">Très Bien</span></td></tr>
              <tr style="background:rgba(212,175,55,0.05);border-top:2px solid rgba(212,175,55,0.3);">
                <td colspan="2"><strong>MOYENNE GÉNÉRALE</strong></td><td><strong>13</strong></td><td><strong>185.5</strong></td>
                <td><strong style="color:#D4AF37;font-size:18px;">14.27/20</strong></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- EMPLOIS -->
    <div id="page-emplois" style="display:none;">
      <div class="topbar-title mb-20">Emploi du Temps — GL3-A</div>
      <div class="card">
        <div class="table-wrapper">
          <table class="schedule-table">
            <thead><tr><th style="width:80px;">Horaire</th><th>Lundi</th><th>Mardi</th><th>Mercredi</th><th>Jeudi</th><th>Vendredi</th><th>Samedi</th></tr></thead>
            <tbody id="edtParentBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ABSENCES -->
    <div id="page-absences" style="display:none;">
      <div class="topbar-title mb-20">Absences de YAO Adjoua</div>
      <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px;">
        <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value" style="color:#22c55e;font-size:24px;">96%</div><div class="stat-label">Taux de présence</div></div>
        <div class="stat-card"><div class="stat-icon">❌</div><div class="stat-value" style="color:#ef4444;font-size:24px;">2</div><div class="stat-label">Absences totales</div></div>
        <div class="stat-card"><div class="stat-icon">⚠️</div><div class="stat-value" style="color:#eab308;font-size:24px;">1</div><div class="stat-label">Non justifiées</div></div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Date</th><th>Cours</th><th>Horaire</th><th>Statut</th><th>Justifiée</th></tr></thead>
            <tbody>
              <tr><td>06/01/2021</td><td>Développement Web PHP</td><td>10:00 – 12:00</td><td><span class="badge badge-danger">❌ Absent</span></td><td><span class="badge badge-danger">✗ Non</span></td></tr>
              <tr><td>20/01/2021</td><td>Anglais des affaires</td><td>14:00 – 15:00</td><td><span class="badge badge-warning">⚠️ Retard</span></td><td><span class="badge badge-success">✓ Oui</span></td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- INFOS -->
    <div id="page-infos" style="display:none;">
      <div class="topbar-title mb-20">Informations de l'établissement</div>
      <div class="card mb-20"><div class="card-body">
        <div style="display:flex;gap:16px;align-items:flex-start;">
          <span style="font-size:32px;">📋</span>
          <div><div style="font-family:Playfair Display,serif;font-size:16px;font-weight:600;margin-bottom:6px;">Examens de fin de Trimestre 1</div>
          <p style="color:var(--text-secondary);font-size:14px;line-height:1.6;">Les examens du Trimestre 1 se tiendront du 20 au 28 janvier 2021. Votre enfant doit se présenter avec sa carte d'étudiant.</p>
          <div style="font-size:12px;color:var(--text-muted);margin-top:8px;">📅 15 Janvier 2021</div></div>
        </div>
      </div></div>
      <div class="card mb-20"><div class="card-body">
        <div style="display:flex;gap:16px;align-items:flex-start;">
          <span style="font-size:32px;">💰</span>
          <div><div style="font-family:Playfair Display,serif;font-size:16px;font-weight:600;margin-bottom:6px;">Rappel de paiement de scolarité</div>
          <p style="color:var(--text-secondary);font-size:14px;line-height:1.6;">Le règlement du deuxième trimestre est attendu avant le 15 février 2021. Contactez la comptabilité pour tout arrangement.</p>
          <div style="font-size:12px;color:var(--text-muted);margin-top:8px;">📅 08 Janvier 2021</div></div>
        </div>
      </div></div>
    </div>

  </div>
</div>

<script src="../js/app.js"></script>
<script>
const pages=['dashboard','notes','emplois','absences','infos'];
function showPage(page){
  pages.forEach(p=>{const el=document.getElementById('page-'+p);if(el)el.style.display=p===page?'':'none';});
  document.getElementById('pageTitle').textContent={dashboard:'Tableau de bord',notes:'Notes & Bulletins',emplois:'Emploi du Temps',absences:'Absences',infos:'Informations'}[page]||page;
  document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
  if(page==='emplois')renderEDT();
  document.querySelector('.sidebar')?.classList.remove('open');
}

const edtData=[
  {jour:'Lundi',debut:'08:00',fin:'10:00',cours:'Base de Données',salle:'S.101',enseignant:'COULIBALY JP'},
  {jour:'Lundi',debut:'10:00',fin:'12:00',cours:'UML',salle:'S.201',enseignant:'COULIBALY JP'},
  {jour:'Mercredi',debut:'08:00',fin:'10:00',cours:'Algorithmique',salle:'S.301',enseignant:'DIALLO A.'},
  {jour:'Mercredi',debut:'14:00',fin:'16:00',cours:'Web PHP',salle:'S.102',enseignant:'COULIBALY JP'},
  {jour:'Vendredi',debut:'10:00',fin:'12:00',cours:'Réseaux',salle:'S.401',enseignant:'KONE F.'},
  {jour:'Vendredi',debut:'14:00',fin:'15:00',cours:'Anglais',salle:'S.201',enseignant:'SMITH J.'},
];

function renderEDT(){
  const jours=['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
  const heures=['07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00'];
  let html='';
  heures.forEach((h,i)=>{
    if(i>=heures.length-1)return;
    const hFin=heures[i+1];
    html+=`<tr><td style="color:var(--text-muted);font-size:12px;white-space:nowrap;">${h}–${hFin}</td>`;
    jours.forEach(j=>{
      const slot=edtData.find(e=>e.jour===j&&e.debut<=h&&e.fin>=hFin);
      html+=`<td style="padding:4px;">`;
      if(slot)html+=`<div class="schedule-cell"><div class="subject">${slot.cours}</div><div class="teacher">${slot.enseignant}</div><div class="room">${slot.salle}</div></div>`;
      html+=`</td>`;
    });
    html+='</tr>';
  });
  document.getElementById('edtParentBody').innerHTML=html;
}

document.getElementById('annonceParent').innerHTML=`
  <div style="display:flex;flex-direction:column;gap:10px;">
  <div style="display:flex;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);"><span>📋</span><div><div style="font-size:13px;font-weight:500;">Examens T1 du 20 au 28 janvier</div><div style="font-size:11px;color:var(--text-muted);">15 Jan</div></div></div>
  <div style="display:flex;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);"><span>💰</span><div><div style="font-size:13px;font-weight:500;">Rappel paiement scolarité T2</div><div style="font-size:11px;color:var(--text-muted);">08 Jan</div></div></div>
  <div style="display:flex;gap:10px;align-items:center;padding:8px 0;"><span>🚌</span><div><div style="font-size:13px;font-weight:500;">Sortie pédagogique — 25 janvier</div><div style="font-size:11px;color:var(--text-muted);">10 Jan</div></div></div>
  </div>`;

setTimeout(()=>{ drawBarChart('chartParent',['BD','PHP','UML','Algo','Réseaux','Anglais'],[14.5,16,13,12,15,17],'#1a4080'); },200);
</script>
</body>
</html>
