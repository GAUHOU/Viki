<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('administrateur','responsable','enseignant');

$db = getDB(); $method = $_SERVER['REQUEST_METHOD']; $input = getInput();

if ($method === 'GET') {
    $filiereId = $input['id_filiere'] ?? null;
    $ensId     = $input['id_ens']     ?? null;
    $sql = "SELECT co.*,f.nom_filiere,f.code_filiere,
                   CONCAT(u.nom,' ',u.prenoms) AS nom_enseignant
            FROM cours co
            JOIN filiere f ON f.id_filiere=co.id_filiere
            JOIN enseignant en ON en.id_ens=co.id_ens
            JOIN utilisateur u ON u.id_utilisateur=en.id_utilisateur
            WHERE 1=1";
    $params=[];
    if ($filiereId) { $sql.=" AND co.id_filiere=?"; $params[]=$filiereId; }
    if ($ensId)     { $sql.=" AND co.id_ens=?";      $params[]=$ensId; }
    $sql .= " ORDER BY co.matiere,co.intitule";
    $stmt=$db->prepare($sql); $stmt->execute($params);
    jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);
}

if ($method === 'POST') {
    requireRole('administrateur','responsable');
    $intitule=sanitize($input['intitule']??''); $matiere=sanitize($input['matiere']??'');
    $filiereId=(int)($input['id_filiere']??0); $ensId=(int)($input['id_ens']??0); $salle=sanitize($input['salle']??'');
    if (!$intitule||!$matiere||!$filiereId||!$ensId) jsonResponse(['success'=>false,'message'=>'Données manquantes'],400);
    $db->prepare("INSERT INTO cours (intitule,matiere,salle,id_filiere,id_ens) VALUES (?,?,?,?,?)")->execute([$intitule,$matiere,$salle,$filiereId,$ensId]);
    jsonResponse(['success'=>true,'message'=>"Cours créé",'id'=>$db->lastInsertId()],201);
}

if ($method === 'PUT') {
    requireRole('administrateur','responsable');
    $id=(int)($input['id']??0); $intitule=sanitize($input['intitule']??''); $matiere=sanitize($input['matiere']??'');
    $filiereId=(int)($input['id_filiere']??0); $ensId=(int)($input['id_ens']??0); $salle=sanitize($input['salle']??'');
    if (!$id||!$intitule) jsonResponse(['success'=>false,'message'=>'Données manquantes'],400);
    $db->prepare("UPDATE cours SET intitule=?,matiere=?,salle=?,id_filiere=?,id_ens=? WHERE idcours=?")->execute([$intitule,$matiere,$salle,$filiereId,$ensId,$id]);
    jsonResponse(['success'=>true,'message'=>'Cours mis à jour']);
}

if ($method === 'DELETE') {
    requireRole('administrateur');
    $id=(int)($input['id']??0); if (!$id) jsonResponse(['success'=>false,'message'=>'ID manquant'],400);
    $db->prepare("DELETE FROM cours WHERE idcours=?")->execute([$id]);
    jsonResponse(['success'=>true,'message'=>'Cours supprimé']);
}
?>
