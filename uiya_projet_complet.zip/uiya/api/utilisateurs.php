<?php
/**
 * API Utilisateurs — CRUD complet
 * GET    /api/utilisateurs.php          → liste
 * GET    /api/utilisateurs.php?id=X     → un utilisateur
 * POST   /api/utilisateurs.php          → créer
 * PUT    /api/utilisateurs.php          → modifier (id dans body)
 * DELETE /api/utilisateurs.php?id=X     → supprimer
 */
require_once __DIR__ . '/../includes/config.php';
requireRole('administrateur', 'responsable');

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$input  = getInput();

// ── GET ──────────────────────────────────────────
if ($method === 'GET') {
    $id   = $input['id']   ?? null;
    $role = $input['role'] ?? null;
    $q    = $input['q']    ?? null;

    if ($id) {
        // Un seul utilisateur
        $stmt = $db->prepare("SELECT id_utilisateur,nom,prenoms,email,type_utilisateur,genre,telephone,adresse FROM utilisateur WHERE id_utilisateur=?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        if (!$user) jsonResponse(['success'=>false,'message'=>'Utilisateur introuvable'],404);
        jsonResponse(['success'=>true,'data'=>$user]);
    }

    // Liste avec filtres
    $where = []; $params = [];
    if ($role)  { $where[] = 'type_utilisateur = ?'; $params[] = $role; }
    if ($q)     { $where[] = '(nom LIKE ? OR prenoms LIKE ? OR email LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; $params[] = "%$q%"; }

    $sql = "SELECT id_utilisateur,nom,prenoms,email,type_utilisateur,genre,telephone,adresse
            FROM utilisateur" . ($where ? ' WHERE '.implode(' AND ',$where) : '') . " ORDER BY nom,prenoms";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);
}

// ── POST — Créer un utilisateur ──────────────────
if ($method === 'POST') {
    requireRole('administrateur');
    $nom      = sanitize($input['nom']      ?? '');
    $prenoms  = sanitize($input['prenoms']  ?? '');
    $email    = trim($input['email']         ?? '');
    $role     = sanitize($input['role']      ?? '');
    $genre    = sanitize($input['genre']     ?? 'M');
    $tel      = sanitize($input['telephone'] ?? '');
    $adresse  = sanitize($input['adresse']   ?? '');
    $password = $input['password']           ?? 'Uiya@2024';

    $rolesValides = ['administrateur','responsable','enseignant','etudiant','parent'];

    if (!$nom || !$prenoms || !$email || !$role)
        jsonResponse(['success'=>false,'message'=>'Champs obligatoires manquants'],400);
    if (!filter_var($email,FILTER_VALIDATE_EMAIL))
        jsonResponse(['success'=>false,'message'=>'Email invalide'],400);
    if (!in_array($role,$rolesValides,true))
        jsonResponse(['success'=>false,'message'=>'Rôle invalide'],400);

    // Vérifier email unique
    $check = $db->prepare("SELECT id_utilisateur FROM utilisateur WHERE email=?");
    $check->execute([$email]);
    if ($check->fetch()) jsonResponse(['success'=>false,'message'=>'Cet email est déjà utilisé'],409);

    // Récupérer l'idrole
    $roleRow = $db->prepare("SELECT idrole FROM role WHERE libelle=? LIMIT 1");
    $roleRow->execute([ucfirst($role)]);
    $roleData = $roleRow->fetch();
    $idrole = $roleData['idrole'] ?? 4;

    $db->beginTransaction();
    try {
        // Insérer dans utilisateur
        $stmt = $db->prepare("INSERT INTO utilisateur (nom,prenoms,email,mot_de_passe,type_utilisateur,genre,telephone,adresse,idrole)
                              VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$nom,$prenoms,$email,hashPassword($password),$role,$genre,$tel,$adresse,$idrole]);
        $newId = (int)$db->lastInsertId();

        // Insérer dans la table spécifique selon le rôle
        switch ($role) {
            case 'administrateur':
                $db->prepare("INSERT INTO administrateur (id_utilisateur,mot_de_passe) VALUES (?,?)")
                   ->execute([$newId, hashPassword($password)]);
                break;
            case 'responsable':
                $filiereId = (int)($input['id_filiere'] ?? 1);
                $db->prepare("INSERT INTO responsable (id_utilisateur,statut,id_filiere) VALUES (?,?,?)")
                   ->execute([$newId,'actif',$filiereId]);
                break;
            case 'enseignant':
                $specialite = sanitize($input['specialite'] ?? 'Non définie');
                $db->prepare("INSERT INTO enseignant (id_utilisateur,specialite) VALUES (?,?)")
                   ->execute([$newId,$specialite]);
                break;
            case 'etudiant':
                $dateNaiss  = $input['date_naissance'] ?? '2000-01-01';
                $annee      = sanitize($input['annee_scolaire'] ?? date('Y').'-'.(date('Y')+1));
                $nationalite= sanitize($input['nationalite'] ?? 'Ivoirienne');
                $classeId   = (int)($input['id_cl'] ?? 1);
                $db->prepare("INSERT INTO etudiant (id_utilisateur,date_naissance,annee_scolaire,nationalite,id_cl) VALUES (?,?,?,?,?)")
                   ->execute([$newId,$dateNaiss,$annee,$nationalite,$classeId]);
                break;
            case 'parent':
                $lien = sanitize($input['lien_parent'] ?? 'Tuteur');
                $db->prepare("INSERT INTO parent (id_utilisateur,lien_parent) VALUES (?,?)")
                   ->execute([$newId,$lien]);
                break;
        }

        $db->commit();
        jsonResponse(['success'=>true,'message'=>"Utilisateur $nom $prenoms créé avec succès",'id'=>$newId],201);
    } catch (Exception $e) {
        $db->rollBack();
        jsonResponse(['success'=>false,'message'=>'Erreur : '.$e->getMessage()],500);
    }
}

// ── PUT — Modifier ───────────────────────────────
if ($method === 'PUT') {
    requireRole('administrateur');
    $id      = (int)($input['id'] ?? 0);
    $nom     = sanitize($input['nom']      ?? '');
    $prenoms = sanitize($input['prenoms']  ?? '');
    $email   = trim($input['email']         ?? '');
    $genre   = sanitize($input['genre']     ?? 'M');
    $tel     = sanitize($input['telephone'] ?? '');
    $adresse = sanitize($input['adresse']   ?? '');

    if (!$id || !$nom || !$prenoms || !$email)
        jsonResponse(['success'=>false,'message'=>'Champs obligatoires manquants'],400);

    // Email unique sauf pour cet utilisateur
    $check = $db->prepare("SELECT id_utilisateur FROM utilisateur WHERE email=? AND id_utilisateur!=?");
    $check->execute([$email,$id]);
    if ($check->fetch()) jsonResponse(['success'=>false,'message'=>'Email déjà utilisé par un autre compte'],409);

    $stmt = $db->prepare("UPDATE utilisateur SET nom=?,prenoms=?,email=?,genre=?,telephone=?,adresse=? WHERE id_utilisateur=?");
    $stmt->execute([$nom,$prenoms,$email,$genre,$tel,$adresse,$id]);

    // Changer le mot de passe si fourni
    if (!empty($input['password'])) {
        $db->prepare("UPDATE utilisateur SET mot_de_passe=? WHERE id_utilisateur=?")
           ->execute([hashPassword($input['password']),$id]);
    }

    jsonResponse(['success'=>true,'message'=>'Utilisateur mis à jour']);
}

// ── DELETE ───────────────────────────────────────
if ($method === 'DELETE') {
    requireRole('administrateur');
    $id = (int)($input['id'] ?? 0);
    if (!$id) jsonResponse(['success'=>false,'message'=>'ID manquant'],400);
    // Protection : ne pas supprimer son propre compte
    if ($id === (int)$_SESSION['user_id'])
        jsonResponse(['success'=>false,'message'=>'Vous ne pouvez pas supprimer votre propre compte'],403);
    $db->prepare("DELETE FROM utilisateur WHERE id_utilisateur=?")->execute([$id]);
    jsonResponse(['success'=>true,'message'=>'Utilisateur supprimé']);
}
?>
