<?php
/**
 * API Auth - Connexion / Déconnexion
 * POST /includes/auth.php  { email, password, role }
 */
require_once __DIR__ . '/config.php';

$input = getInput();
$action = $input['action'] ?? 'login';

// ── DÉCONNEXION ──────────────────────────────────
if ($action === 'logout') {
    session_destroy();
    jsonResponse(['success' => true, 'redirect' => APP_URL . '/index.html']);
}

// ── CONNEXION ────────────────────────────────────
$email    = trim($input['email']    ?? '');
$password = trim($input['password'] ?? '');
$role     = trim($input['role']     ?? '');

// Validation basique
if (!$email || !$password) {
    jsonResponse(['success' => false, 'message' => 'Email et mot de passe requis.'], 400);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonResponse(['success' => false, 'message' => 'Email invalide.'], 400);
}

$db = getDB();

// Chercher l'utilisateur par email ET type
$stmt = $db->prepare("
    SELECT u.id_utilisateur, u.nom, u.prenoms, u.email,
           u.type_utilisateur, u.genre,
           a.mot_de_passe AS hash_admin,
           u.idrole
    FROM utilisateur u
    LEFT JOIN administrateur a ON a.id_utilisateur = u.id_utilisateur
    WHERE u.email = :email
    LIMIT 1
");
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

if (!$user) {
    jsonResponse(['success' => false, 'message' => 'Aucun compte trouvé avec cet email.'], 401);
}

// Vérification mot de passe
// Les admins ont leur hash dans la table administrateur,
// les autres utilisateurs utilisent le hash SHA2 de démonstration.
// En production tous les hash seront bcrypt.
$hashToCheck = $user['hash_admin'] ?? '';

// Fallback : reconstruire hash SHA2 pour démo
$sha2Demo = hash('sha256', $password);

// Map des hash de démo selon le rôle (correspondance données SQL)
$demoHashes = [
    'administrateur' => hash('sha256', 'Admin@2024'),
    'responsable'    => hash('sha256', 'Resp@2024'),
    'enseignant'     => hash('sha256', 'Ens@2024'),
    'etudiant'       => hash('sha256', 'Etu@2024'),
    'parent'         => hash('sha256', 'Par@2024'),
];

$passwordOk = false;
if ($hashToCheck && verifyPassword($password, $hashToCheck)) {
    $passwordOk = true;
} elseif (isset($demoHashes[$user['type_utilisateur']]) && $sha2Demo === $demoHashes[$user['type_utilisateur']]) {
    $passwordOk = true;
}

if (!$passwordOk) {
    jsonResponse(['success' => false, 'message' => 'Mot de passe incorrect.'], 401);
}

// Vérifier que le rôle correspond
if ($role && $user['type_utilisateur'] !== $role) {
    jsonResponse([
        'success' => false,
        'message' => "Ce compte n'est pas un compte « {$role} »."
    ], 401);
}

// Démarrer la session
$_SESSION['user_id']    = $user['id_utilisateur'];
$_SESSION['user_name']  = $user['nom'] . ' ' . $user['prenoms'];
$_SESSION['user_email'] = $user['email'];
$_SESSION['user_type']  = $user['type_utilisateur'];
$_SESSION['user_genre'] = $user['genre'];
$_SESSION['idrole']     = $user['idrole'];
$_SESSION['last_activity'] = time();

// Redirection selon le rôle
$redirectMap = [
    'administrateur' => APP_URL . '/admin/dashboard.php',
    'responsable'    => APP_URL . '/responsable/dashboard.php',
    'enseignant'     => APP_URL . '/enseignant/dashboard.php',
    'etudiant'       => APP_URL . '/etudiant/dashboard.php',
    'parent'         => APP_URL . '/parent/dashboard.php',
];

$redirect = $redirectMap[$user['type_utilisateur']] ?? APP_URL . '/index.html';

// Mettre à jour la session en BDD (log de connexion - optionnel)
// $db->prepare("INSERT INTO connexion_log (id_utilisateur, date_connexion) VALUES (?,NOW())")->execute([$user['id_utilisateur']]);

jsonResponse([
    'success'  => true,
    'message'  => 'Connexion réussie',
    'redirect' => $redirect,
    'user' => [
        'id'    => $user['id_utilisateur'],
        'nom'   => $user['nom'],
        'prenom'=> $user['prenoms'],
        'email' => $user['email'],
        'role'  => $user['type_utilisateur'],
    ]
]);
?>
