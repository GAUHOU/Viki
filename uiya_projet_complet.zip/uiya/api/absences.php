<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('administrateur','responsable','enseignant','etudiant','parent');

$db = getDB(); $method = $_SERVER['REQUEST_METHOD']; $input = getInput();

if ($method === 'GET') {
    $etuId   = $input['id_ed']   ?? null;
    $classeId= $input['id_cl']   ?? null;
    $statut  = $input['statut']  ?? null;
    $date    = $input['date']    ?? null;

    // Restreindre selon rôle
    if ($_SESSION['user_type']==='etudiant') {
        $stmt=$db->prepare("SELECT id_ed FROM etudiant WHERE id_utilisateur=?");
        $stmt->execute([$_SESSION['user_id']]); $etu=$stmt->fetch();
        $etuId=$etu['id_ed']??null;
    }
    if ($_SESSION['user_type']==='enseignant') {
        $stmt=$db->prepare("SELECT id_ens FROM enseignant WHERE id_utilisateur=?");
        $stmt->execute([$_SESSION['user_id']]); $ens=$stmt->fetch();
        // Filtrer par cours de cet enseignant
    }
    if ($_SESSION['user_type']==='parent') {
        $stmt=$db->prepare("SELECT pe.id_ed FROM parent_etudiant pe JOIN parent p ON p.idParent=pe.idParent WHERE p.id_utilisateur=?");
        $stmt->execute([$_SESSION['user_id']]); $enfants=$stmt->fetchAll(PDO::FETCH_COLUMN);
        if (!$etuId && $enfants) $etuId=$enfants[0];
    }

    $sql="SELECT p.*,CONCAT(u.nom,' ',u.prenoms) AS nom_etudiant,cl.nom_cl,
               edt.jour,edt.heur_debut,edt.heur_fin,co.matiere,co.intitule
          FROM presence p
          JOIN etudiant e ON e.id_ed=p.id_ed
          JOIN utilisateur u ON u.id_utilisateur=e.id_utilisateur
          JOIN classe cl ON cl.id_cl=e.id_cl
          JOIN emploi_du_temps edt ON edt.idEmploiDuTemps=p.idEmploiDuTemps
          JOIN cours co ON co.idcours=edt.idcours
          WHERE p.statut IN ('absent','retard')";
    $params=[];
    if ($etuId)    { $sql.=" AND p.id_ed=?";            $params[]=$etuId; }
    if ($classeId) { $sql.=" AND e.id_cl=?";            $params[]=$classeId; }
    if ($statut)   { $sql.=" AND p.statut=?";           $params[]=$statut; }
    if ($date)     { $sql.=" AND p.datepresence=?";     $params[]=$date; }
    $sql .= " ORDER BY p.datepresence DESC";
    $stmt=$db->prepare($sql); $stmt->execute($params);
    jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);
}

if ($method === 'POST') {
    requireRole('administrateur','responsable','enseignant');
    $etuId   =(int)($input['id_ed']           ??0);
    $edtId   =(int)($input['idEmploiDuTemps'] ??0);
    $date    = $input['datepresence']          ??date('Y-m-d');
    $statut  = $input['statut']                ??'absent';
    $justif  = (int)($input['justifiee']       ??0);

    if (!$etuId||!$edtId) jsonResponse(['success'=>false,'message'=>'Données manquantes'],400);
    if (!in_array($statut,['present','absent','retard'])) jsonResponse(['success'=>false,'message'=>'Statut invalide'],400);

    // Vérifier si déjà enregistré pour ce cours/date
    $check=$db->prepare("SELECT idpresence FROM presence WHERE id_ed=? AND idEmploiDuTemps=? AND datepresence=?");
    $check->execute([$etuId,$edtId,$date]);
    if ($existing=$check->fetch()) {
        $db->prepare("UPDATE presence SET statut=?,justifiee=? WHERE idpresence=?")->execute([$statut,$justif,$existing['idpresence']]);
        jsonResponse(['success'=>true,'message'=>'Présence mise à jour','id'=>$existing['idpresence']]);
    }
    $db->prepare("INSERT INTO presence (datepresence,statut,justifiee,id_ed,idEmploiDuTemps) VALUES (?,?,?,?,?)")
       ->execute([$date,$statut,$justif,$etuId,$edtId]);
    jsonResponse(['success'=>true,'message'=>'Absence enregistrée','id'=>$db->lastInsertId()],201);
}

if ($method === 'PUT') {
    requireRole('administrateur','responsable','enseignant');
    $id=(int)($input['id']??0); $statut=$input['statut']??'absent'; $justif=(int)($input['justifiee']??0);
    if (!$id) jsonResponse(['success'=>false,'message'=>'ID manquant'],400);
    $db->prepare("UPDATE presence SET statut=?,justifiee=? WHERE idpresence=?")->execute([$statut,$justif,$id]);
    jsonResponse(['success'=>true,'message'=>'Mise à jour effectuée']);
}

if ($method === 'DELETE') {
    requireRole('administrateur','responsable');
    $id=(int)($input['id']??0); if (!$id) jsonResponse(['success'=>false,'message'=>'ID manquant'],400);
    $db->prepare("DELETE FROM presence WHERE idpresence=?")->execute([$id]);
    jsonResponse(['success'=>true,'message'=>'Enregistrement supprimé']);
}
?>
