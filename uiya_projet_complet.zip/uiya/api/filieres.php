<?php
/**
 * API Filières
 */
require_once __DIR__ . '/../includes/config.php';
requireRole('administrateur','responsable');

$db = getDB(); $method = $_SERVER['REQUEST_METHOD']; $input = getInput();

if ($method === 'GET') {
    $id = $input['id'] ?? null;
    if ($id) {
        $stmt = $db->prepare("SELECT f.*,CONCAT(u.nom,' ',u.prenoms) AS nom_responsable,
            (SELECT COUNT(*) FROM etudiant e JOIN classe c ON e.id_cl=c.id_cl WHERE c.id_filiere=f.id_filiere) AS nb_etudiants
            FROM filiere f LEFT JOIN responsable r ON r.id_rep=f.resp_filiere
            LEFT JOIN utilisateur u ON u.id_utilisateur=r.id_utilisateur WHERE f.id_filiere=?");
        $stmt->execute([$id]); $f = $stmt->fetch();
        if (!$f) jsonResponse(['success'=>false,'message'=>'Filière introuvable'],404);
        jsonResponse(['success'=>true,'data'=>$f]);
    }
    $stmt = $db->query("SELECT f.*,CONCAT(u.nom,' ',u.prenoms) AS nom_responsable,
        (SELECT COUNT(*) FROM etudiant e JOIN classe c ON e.id_cl=c.id_cl WHERE c.id_filiere=f.id_filiere) AS nb_etudiants
        FROM filiere f LEFT JOIN responsable r ON r.id_rep=f.resp_filiere
        LEFT JOIN utilisateur u ON u.id_utilisateur=r.id_utilisateur ORDER BY f.nom_filiere");
    jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);
}

if ($method === 'POST') {
    requireRole('administrateur');
    $code    = strtoupper(sanitize($input['code_filiere'] ?? ''));
    $nom     = sanitize($input['nom_filiere'] ?? '');
    $niveau  = sanitize($input['niveau'] ?? '');
    $resp    = $input['resp_filiere'] ? (int)$input['resp_filiere'] : null;
    if (!$code||!$nom||!$niveau) jsonResponse(['success'=>false,'message'=>'Champs obligatoires manquants'],400);
    $check=$db->prepare("SELECT id_filiere FROM filiere WHERE code_filiere=?"); $check->execute([$code]);
    if ($check->fetch()) jsonResponse(['success'=>false,'message'=>'Code filière déjà existant'],409);
    $stmt=$db->prepare("INSERT INTO filiere (code_filiere,nom_filiere,niveau,resp_filiere) VALUES (?,?,?,?)");
    $stmt->execute([$code,$nom,$niveau,$resp]);
    jsonResponse(['success'=>true,'message'=>"Filière $nom créée",'id'=>$db->lastInsertId()],201);
}

if ($method === 'PUT') {
    requireRole('administrateur');
    $id=$input['id']??0; $code=strtoupper(sanitize($input['code_filiere']??'')); $nom=sanitize($input['nom_filiere']??''); $niveau=sanitize($input['niveau']??''); $resp=$input['resp_filiere']?(int)$input['resp_filiere']:null;
    if (!$id||!$code||!$nom) jsonResponse(['success'=>false,'message'=>'Données manquantes'],400);
    $db->prepare("UPDATE filiere SET code_filiere=?,nom_filiere=?,niveau=?,resp_filiere=? WHERE id_filiere=?")->execute([$code,$nom,$niveau,$resp,$id]);
    jsonResponse(['success'=>true,'message'=>'Filière mise à jour']);
}

if ($method === 'DELETE') {
    requireRole('administrateur');
    $id=(int)($input['id']??0); if (!$id) jsonResponse(['success'=>false,'message'=>'ID manquant'],400);
    // Vérifier qu'aucun étudiant n'est lié
    $stmt=$db->prepare("SELECT COUNT(*) AS n FROM classe WHERE id_filiere=?"); $stmt->execute([$id]); $r=$stmt->fetch();
    if ($r['n']>0) jsonResponse(['success'=>false,'message'=>'Impossible : des classes sont liées à cette filière'],409);
    $db->prepare("DELETE FROM filiere WHERE id_filiere=?")->execute([$id]);
    jsonResponse(['success'=>true,'message'=>'Filière supprimée']);
}
?>
