<?php
/**
 * API Classes
 */
require_once __DIR__ . '/../includes/config.php';
requireRole('administrateur','responsable');

$db = getDB(); $method = $_SERVER['REQUEST_METHOD']; $input = getInput();

if ($method === 'GET') {
    $filiereId = $input['id_filiere'] ?? null;
    $sql = "SELECT c.*,f.nom_filiere,f.code_filiere,
            (SELECT COUNT(*) FROM etudiant e WHERE e.id_cl=c.id_cl) AS nb_etudiants_reels
            FROM classe c JOIN filiere f ON f.id_filiere=c.id_filiere";
    $params = [];
    if ($filiereId) { $sql .= " WHERE c.id_filiere=?"; $params[]=$filiereId; }
    $sql .= " ORDER BY f.nom_filiere,c.nom_cl";
    $stmt=$db->prepare($sql); $stmt->execute($params);
    jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);
}

if ($method === 'POST') {
    requireRole('administrateur');
    $nom=$input['nom_cl']??''; $filiereId=(int)($input['id_filiere']??0); $effectif=(int)($input['effectif']??30);
    if (!$nom||!$filiereId) jsonResponse(['success'=>false,'message'=>'Données manquantes'],400);
    $db->prepare("INSERT INTO classe (nom_cl,effectif,id_filiere) VALUES (?,?,?)")->execute([$nom,$effectif,$filiereId]);
    jsonResponse(['success'=>true,'message'=>"Classe $nom créée",'id'=>$db->lastInsertId()],201);
}

if ($method === 'PUT') {
    requireRole('administrateur');
    $id=$input['id']??0; $nom=$input['nom_cl']??''; $filiereId=(int)($input['id_filiere']??0); $effectif=(int)($input['effectif']??30);
    if (!$id||!$nom) jsonResponse(['success'=>false,'message'=>'Données manquantes'],400);
    $db->prepare("UPDATE classe SET nom_cl=?,effectif=?,id_filiere=? WHERE id_cl=?")->execute([$nom,$effectif,$filiereId,$id]);
    jsonResponse(['success'=>true,'message'=>'Classe mise à jour']);
}

if ($method === 'DELETE') {
    requireRole('administrateur');
    $id=(int)($input['id']??0); if (!$id) jsonResponse(['success'=>false,'message'=>'ID manquant'],400);
    $check=$db->prepare("SELECT COUNT(*) AS n FROM etudiant WHERE id_cl=?"); $check->execute([$id]); $r=$check->fetch();
    if ($r['n']>0) jsonResponse(['success'=>false,'message'=>'Des étudiants sont inscrits dans cette classe'],409);
    $db->prepare("DELETE FROM classe WHERE id_cl=?")->execute([$id]);
    jsonResponse(['success'=>true,'message'=>'Classe supprimée']);
}
?>
