/**
 * UIYA — API Client
 * Toutes les fonctions d'appel vers les APIs PHP/MySQL
 */

const BASE = '..'; // relatif depuis admin/, etudiant/, etc.

// ══════════════════════════════════════════════════
//  FONCTION FETCH CENTRALISÉE
// ══════════════════════════════════════════════════
async function apiCall(url, method = 'GET', data = null) {
  const opts = {
    method,
    headers: { 'X-Requested-With': 'XMLHttpRequest' },
    credentials: 'same-origin',
  };
  if (data && method !== 'GET') {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(data);
  }
  // Pour DELETE avec body
  if (method === 'DELETE' && data) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(data);
  }

  try {
    const res = await fetch(url, opts);
    const json = await res.json();

    if (res.status === 401) {
      window.location.href = BASE + '/index.html?error=session_expired';
      return null;
    }
    if (res.status === 403) {
      showToast('Accès refusé', 'error');
      return null;
    }
    return json;
  } catch (e) {
    // Mode démo : pas de serveur PHP — utiliser localStorage
    console.warn('Mode démo (pas de serveur PHP) :', e.message);
    return null; // le code appelant gère le fallback
  }
}

// ══════════════════════════════════════════════════
//  UTILISATEURS
// ══════════════════════════════════════════════════
const UtilisateurAPI = {
  async liste(role = '', q = '') {
    let url = `${BASE}/api/utilisateurs.php?`;
    if (role) url += `role=${role}&`;
    if (q)    url += `q=${encodeURIComponent(q)}`;
    return await apiCall(url);
  },
  async get(id) {
    return await apiCall(`${BASE}/api/utilisateurs.php?id=${id}`);
  },
  async creer(data) {
    return await apiCall(`${BASE}/api/utilisateurs.php`, 'POST', data);
  },
  async modifier(data) {
    return await apiCall(`${BASE}/api/utilisateurs.php`, 'PUT', data);
  },
  async supprimer(id) {
    return await apiCall(`${BASE}/api/utilisateurs.php`, 'DELETE', { id });
  },
};

// ══════════════════════════════════════════════════
//  FILIÈRES
// ══════════════════════════════════════════════════
const FiliereAPI = {
  async liste() {
    return await apiCall(`${BASE}/api/filieres.php`);
  },
  async creer(data) {
    return await apiCall(`${BASE}/api/filieres.php`, 'POST', data);
  },
  async modifier(data) {
    return await apiCall(`${BASE}/api/filieres.php`, 'PUT', data);
  },
  async supprimer(id) {
    return await apiCall(`${BASE}/api/filieres.php`, 'DELETE', { id });
  },
};

// ══════════════════════════════════════════════════
//  CLASSES
// ══════════════════════════════════════════════════
const ClasseAPI = {
  async liste(filiereId = '') {
    let url = `${BASE}/api/classes.php`;
    if (filiereId) url += `?id_filiere=${filiereId}`;
    return await apiCall(url);
  },
  async creer(data) {
    return await apiCall(`${BASE}/api/classes.php`, 'POST', data);
  },
  async modifier(data) {
    return await apiCall(`${BASE}/api/classes.php`, 'PUT', data);
  },
  async supprimer(id) {
    return await apiCall(`${BASE}/api/classes.php`, 'DELETE', { id });
  },
};

// ══════════════════════════════════════════════════
//  COURS
// ══════════════════════════════════════════════════
const CoursAPI = {
  async liste(filiereId = '', ensId = '') {
    let url = `${BASE}/api/cours.php?`;
    if (filiereId) url += `id_filiere=${filiereId}&`;
    if (ensId)     url += `id_ens=${ensId}`;
    return await apiCall(url);
  },
  async creer(data) {
    return await apiCall(`${BASE}/api/cours.php`, 'POST', data);
  },
  async modifier(data) {
    return await apiCall(`${BASE}/api/cours.php`, 'PUT', data);
  },
  async supprimer(id) {
    return await apiCall(`${BASE}/api/cours.php`, 'DELETE', { id });
  },
};

// ══════════════════════════════════════════════════
//  EMPLOIS DU TEMPS
// ══════════════════════════════════════════════════
const EmploiAPI = {
  async liste(filiereId = '', classeId = '', ensId = '') {
    let url = `${BASE}/api/emplois_du_temps.php?`;
    if (filiereId) url += `id_filiere=${filiereId}&`;
    if (classeId)  url += `id_cl=${classeId}&`;
    if (ensId)     url += `id_ens=${ensId}`;
    return await apiCall(url);
  },
  async creer(data) {
    return await apiCall(`${BASE}/api/emplois_du_temps.php`, 'POST', data);
  },
  async supprimer(id) {
    return await apiCall(`${BASE}/api/emplois_du_temps.php`, 'DELETE', { id });
  },
};

// ══════════════════════════════════════════════════
//  NOTES
// ══════════════════════════════════════════════════
const NoteAPI = {
  async liste(params = {}) {
    let url = `${BASE}/api/notes.php?`;
    for (const [k, v] of Object.entries(params)) if (v) url += `${k}=${v}&`;
    return await apiCall(url);
  },
  async creer(data) {
    return await apiCall(`${BASE}/api/notes.php`, 'POST', data);
  },
  async modifier(data) {
    return await apiCall(`${BASE}/api/notes.php`, 'PUT', data);
  },
  async supprimer(id) {
    return await apiCall(`${BASE}/api/notes.php`, 'DELETE', { id });
  },
  async moyenne(etuId, trimestre = '') {
    let url = `${BASE}/api/notes.php?action=moyenne&id_ed=${etuId}`;
    if (trimestre) url += `&trimestre=${trimestre}`;
    return await apiCall(url);
  },
};

// ══════════════════════════════════════════════════
//  ABSENCES
// ══════════════════════════════════════════════════
const AbsenceAPI = {
  async liste(params = {}) {
    let url = `${BASE}/api/absences.php?`;
    for (const [k, v] of Object.entries(params)) if (v) url += `${k}=${v}&`;
    return await apiCall(url);
  },
  async creer(data) {
    return await apiCall(`${BASE}/api/absences.php`, 'POST', data);
  },
  async modifier(data) {
    return await apiCall(`${BASE}/api/absences.php`, 'PUT', data);
  },
  async supprimer(id) {
    return await apiCall(`${BASE}/api/absences.php`, 'DELETE', { id });
  },
};

// ══════════════════════════════════════════════════
//  STATISTIQUES
// ══════════════════════════════════════════════════
const StatAPI = {
  async global()             { return await apiCall(`${BASE}/api/statistiques.php?action=global`); },
  async parFiliere()         { return await apiCall(`${BASE}/api/statistiques.php?action=etudiants_par_filiere`); },
  async moyennesParCours(cl) { return await apiCall(`${BASE}/api/statistiques.php?action=moyennes_par_cours&id_cl=${cl||''}`); },
  async absencesParMois()    { return await apiCall(`${BASE}/api/statistiques.php?action=absences_par_mois`); },
  async reussiteParFiliere() { return await apiCall(`${BASE}/api/statistiques.php?action=reussite_par_filiere`); },
  async bulletin(etuId, trim){ return await apiCall(`${BASE}/api/statistiques.php?action=bulletin&id_ed=${etuId}&trimestre=${trim||''}`); },
};

// ══════════════════════════════════════════════════
//  AUTH
// ══════════════════════════════════════════════════
const AuthAPI = {
  async login(email, password, role) {
    return await apiCall(`${BASE}/includes/auth.php`, 'POST', { email, password, role });
  },
  async logout() {
    return await apiCall(`${BASE}/includes/auth.php`, 'POST', { action: 'logout' });
  },
};

// ══════════════════════════════════════════════════
//  HELPER : charger les selects depuis la BDD
// ══════════════════════════════════════════════════
async function populateSelectFromDB(selectId, apiCall, valueKey, labelKey, placeholder = '-- Choisir --') {
  const el = document.getElementById(selectId);
  if (!el) return;
  el.innerHTML = `<option value="">${placeholder}</option>`;
  const res = await apiCall();
  if (res && res.success && res.data) {
    res.data.forEach(item => {
      const opt = document.createElement('option');
      opt.value = item[valueKey];
      opt.textContent = item[labelKey];
      el.appendChild(opt);
    });
  }
}

// ══════════════════════════════════════════════════
//  FALLBACK localStorage (mode démo sans PHP)
// ══════════════════════════════════════════════════
const LocalDB = {
  get(k)    { try { return JSON.parse(localStorage.getItem('uiya_'+k)) || []; } catch(e){ return []; } },
  set(k, v) { localStorage.setItem('uiya_'+k, JSON.stringify(v)); },
  init() {
    if (localStorage.getItem('uiya_initialized')) return;
    this.set('users', [
      {id:1,nom:'DIALLO',prenoms:'Amadou',email:'admin@uiya.ci',role:'administrateur',genre:'M',tel:'+225 07 00 00 01'},
      {id:2,nom:'KONE',prenoms:'Fatoumata',email:'resp.info@uiya.ci',role:'responsable',genre:'F',tel:'+225 07 00 00 02'},
      {id:3,nom:'COULIBALY',prenoms:'Jean-Paul',email:'jp.coulibaly@uiya.ci',role:'enseignant',genre:'M',tel:'+225 07 00 00 03'},
      {id:4,nom:'YAO',prenoms:'Adjoua Victoire',email:'yao.adjoua@uiya.ci',role:'etudiant',genre:'F',tel:'+225 07 00 00 04'},
      {id:5,nom:'KANGA',prenoms:'Arsène',email:'kanga.arsene@uiya.ci',role:'parent',genre:'M',tel:'+225 07 00 00 05'},
    ]);
    this.set('filieres',[
      {id:1,code:'GL',nom:'Génie Logiciel',niveau:'Licence 3',resp:'KONE Fatoumata',etudiants:45},
      {id:2,code:'GRH',nom:'Gestion des RH',niveau:'Master 1',resp:'—',etudiants:38},
      {id:3,code:'CM',nom:'Communication',niveau:'Licence 2',resp:'—',etudiants:52},
    ]);
    this.set('classes',[
      {id:1,nom:'GL3-A',filiere:'Génie Logiciel',effectif:25},
      {id:2,nom:'GL3-B',filiere:'Génie Logiciel',effectif:20},
      {id:3,nom:'GRH-M1',filiere:'Gestion des RH',effectif:38},
    ]);
    this.set('cours',[
      {id:1,intitule:'Conception de bases de données',matiere:'Base de Données',filiere:'Génie Logiciel',enseignant:'COULIBALY Jean-Paul',salle:'Salle 101'},
      {id:2,intitule:'Développement Web PHP',matiere:'Programmation Web',filiere:'Génie Logiciel',enseignant:'COULIBALY Jean-Paul',salle:'Salle 102'},
      {id:3,intitule:'UML & Modélisation',matiere:'Génie Logiciel',filiere:'Génie Logiciel',enseignant:'COULIBALY Jean-Paul',salle:'Salle 103'},
    ]);
    this.set('notes',[
      {id:1,etudiant:'YAO Adjoua',classe:'GL3-A',cours:'Base de Données',matiere:'BD',valeur:14.5,coeff:3,trimestre:1,appreciation:'Assez Bien'},
      {id:2,etudiant:'YAO Adjoua',classe:'GL3-A',cours:'PHP',matiere:'Web',valeur:16,coeff:2,trimestre:1,appreciation:'Bien'},
      {id:3,etudiant:'TRAORÉ Ibrahim',classe:'GL3-A',cours:'Base de Données',matiere:'BD',valeur:12,coeff:3,trimestre:1,appreciation:'Passable'},
    ]);
    this.set('absences',[
      {id:1,etudiant:'YAO Adjoua',classe:'GL3-A',date:'2024-01-06',cours:'PHP',statut:'absent',justifiee:false},
      {id:2,etudiant:'TRAORÉ Ibrahim',classe:'GL3-A',date:'2024-01-08',cours:'UML',statut:'retard',justifiee:true},
    ]);
    this.set('stats',{nb_etudiants:487,nb_enseignants:42,nb_filieres:8,nb_classes:24,nb_cours:96,nb_parents:44,nb_absences:87,nb_non_justif:23});
    localStorage.setItem('uiya_initialized','1');
  }
};

// Init au chargement
document.addEventListener('DOMContentLoaded', () => LocalDB.init());
