<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>UIYA — Espace Responsable</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-icon">U</div><div class="logo-text"><div class="name">UIYA</div><div class="sub">Responsable Filière</div></div></div>
  <div class="sidebar-user">
    <div class="user-avatar" style="background:linear-gradient(135deg,#D4AF37,#f97316);">K</div>
    <div class="user-info"><div class="user-name">KONE Fatoumata</div><div class="user-role" style="color:#D4AF37;">Resp. Génie Logiciel</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-title">Gestion Filière</div>
    <a class="nav-item active" data-page="dashboard" onclick="showPage('dashboard')"><span class="icon">🏠</span> Tableau de bord</a>
    <a class="nav-item" data-page="etudiants" onclick="showPage('etudiants')"><span class="icon">🎓</span> Étudiants</a>
    <a class="nav-item" data-page="emplois" onclick="showPage('emplois')"><span class="icon">📅</span> Emplois du temps</a>
    <a class="nav-item" data-page="notes" onclick="showPage('notes')"><span class="icon">📝</span> Notes & Bulletins</a>
    <a class="nav-item" data-page="absences" onclick="showPage('absences')"><span class="icon">📋</span> Absences <span class="badge">3</span></a>
    <a class="nav-item" data-page="cours" onclick="showPage('cours')"><span class="icon">📚</span> Cours</a>
    <a class="nav-item" data-page="statistiques" onclick="showPage('statistiques')"><span class="icon">📈</span> Statistiques</a>
    <a class="nav-item" data-page="infos" onclick="showPage('infos')"><span class="icon">📢</span> Publier une info</a>
  </nav>
  <div class="sidebar-footer"><a class="nav-item" href="../index.html"><span class="icon">🚪</span> Déconnexion</a></div>
</aside>

<div class="main-content">
  <header class="topbar">
    <div class="topbar-left">
      <button class="topbar-btn hamburger" onclick="toggleSidebar()">☰</button>
      <div><div class="topbar-title" id="pageTitle">Tableau de bord</div><div class="topbar-subtitle">Filière Génie Logiciel — 2020-2021</div></div>
    </div>
    <div class="topbar-right">
      <div class="search-box"><span class="search-icon">🔍</span><input type="text" placeholder="Rechercher..."></div>
      <a class="topbar-btn">🔔</a><a class="topbar-btn" href="../index.html">🚪</a>
    </div>
  </header>

  <div class="page-content">

    <!-- DASHBOARD -->
    <div id="page-dashboard">
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-icon">🎓</div><div class="stat-value" data-counter="65">65</div><div class="stat-label">Étudiants filière</div></div>
        <div class="stat-card"><div class="stat-icon">🏫</div><div class="stat-value" data-counter="3">3</div><div class="stat-label">Classes</div></div>
        <div class="stat-card"><div class="stat-icon">📊</div><div class="stat-value" style="color:#D4AF37;">82%</div><div class="stat-label">Taux de réussite</div><div class="stat-change up">↑ +5% vs S1</div></div>
        <div class="stat-card"><div class="stat-icon">📝</div><div class="stat-value" style="color:#D4AF37;">13.8</div><div class="stat-label">Moyenne filière</div></div>
        <div class="stat-card"><div class="stat-icon">⚠️</div><div class="stat-value" style="color:#ef4444;" data-counter="3">3</div><div class="stat-label">Absences à valider</div></div>
      </div>
      <div class="grid-2 mb-20" style="margin-top:20px;">
        <div class="card">
          <div class="card-header"><span class="card-title">📊 Moyennes par classe</span></div>
          <div class="card-body"><canvas id="chartResp" style="width:100%;height:200px;display:block;"></canvas></div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title">🎯 Taux de réussite</span></div>
          <div class="card-body">
            <div style="display:flex;flex-direction:column;gap:14px;">
              <div><div class="flex-between" style="margin-bottom:6px;"><span style="font-size:13px;">GL3-A</span><strong style="color:#22c55e;">88%</strong></div><div class="progress"><div class="progress-bar" style="width:88%;"></div></div></div>
              <div><div class="flex-between" style="margin-bottom:6px;"><span style="font-size:13px;">GL3-B</span><strong style="color:#22c55e;">92%</strong></div><div class="progress"><div class="progress-bar" style="width:92%;"></div></div></div>
              <div><div class="flex-between" style="margin-bottom:6px;"><span style="font-size:13px;">GL2-A</span><strong style="color:#eab308;">74%</strong></div><div class="progress"><div class="progress-bar" style="width:74%;"></div></div></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ÉTUDIANTS -->
    <div id="page-etudiants" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Étudiants de la filière GL</div></div>
        <div class="search-box"><span class="search-icon">🔍</span><input type="text" id="searchEtu" placeholder="Rechercher..." oninput="filterEtu()"></div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table id="etuTable"><thead><tr><th>#</th><th>Nom complet</th><th>Classe</th><th>Moy. T1</th><th>Présence</th><th>Statut</th></tr></thead>
            <tbody id="etuBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- EMPLOIS DU TEMPS -->
    <div id="page-emplois" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Emplois du Temps GL</div></div>
        <button class="btn btn-primary" onclick="openModal('modalEDT')">➕ Ajouter un créneau</button>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table class="schedule-table">
            <thead><tr><th>Horaire</th><th>Lundi</th><th>Mardi</th><th>Mercredi</th><th>Jeudi</th><th>Vendredi</th><th>Samedi</th></tr></thead>
            <tbody id="edtRespBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- NOTES -->
    <div id="page-notes" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Notes & Validation</div></div>
        <button class="btn btn-primary" onclick="validateAll()">✅ Valider toutes les notes</button>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Étudiant</th><th>Matière</th><th>Note</th><th>Enseignant</th><th>Statut</th><th>Action</th></tr></thead>
            <tbody id="notesRespBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ABSENCES -->
    <div id="page-absences" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Gestion des Absences</div></div>
        <button class="btn btn-primary" onclick="openModal('modalAbs')">➕ Enregistrer</button>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Étudiant</th><th>Classe</th><th>Date</th><th>Cours</th><th>Statut</th><th>Justifiée</th><th>Actions</th></tr></thead>
            <tbody id="absRespBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- COURS -->
    <div id="page-cours" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Cours de la filière GL</div></div>
        <button class="btn btn-primary" onclick="openModal('modalCours')">➕ Nouveau cours</button>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Intitulé</th><th>Matière</th><th>Enseignant</th><th>Salle</th><th>Actions</th></tr></thead>
            <tbody>
              <tr><td><strong>Base de Données</strong></td><td><span class="badge badge-info">BD</span></td><td>COULIBALY JP</td><td>S.101</td><td><button class="btn btn-outline btn-sm">✏️</button></td></tr>
              <tr><td><strong>Développement Web PHP</strong></td><td><span class="badge badge-info">Web</span></td><td>COULIBALY JP</td><td>S.102</td><td><button class="btn btn-outline btn-sm">✏️</button></td></tr>
              <tr><td><strong>UML & Modélisation</strong></td><td><span class="badge badge-info">UML</span></td><td>COULIBALY JP</td><td>S.103</td><td><button class="btn btn-outline btn-sm">✏️</button></td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- STATISTIQUES -->
    <div id="page-statistiques" style="display:none;">
      <div class="topbar-title mb-20">Statistiques de la filière GL</div>
      <div class="grid-2 mb-20">
        <div class="card"><div class="card-header"><span class="card-title">📊 Notes par matière</span></div><div class="card-body"><canvas id="chartStatNotes" style="width:100%;height:200px;display:block;"></canvas></div></div>
        <div class="card"><div class="card-header"><span class="card-title">📅 Absences mensuelles</span></div><div class="card-body"><canvas id="chartStatAbs" style="width:100%;height:200px;display:block;"></canvas></div></div>
      </div>
    </div>

    <!-- INFOS -->
    <div id="page-infos" style="display:none;">
      <div class="topbar-title mb-20">Publier une Information</div>
      <div class="card" style="max-width:640px;">
        <div class="card-body">
          <div class="form-group"><label class="form-label">Titre de l'annonce</label><input type="text" class="form-control" id="infoTitre" placeholder="Ex: Examen de fin de semestre"></div>
          <div class="form-group"><label class="form-label">Destinataires</label>
            <select class="form-control" id="infoDest">
              <option value="all">Tous (étudiants + parents)</option>
              <option value="etudiants">Étudiants seulement</option>
              <option value="parents">Parents seulement</option>
            </select>
          </div>
          <div class="form-group"><label class="form-label">Contenu</label><textarea class="form-control" id="infoContenu" rows="5" placeholder="Rédigez votre annonce ici..."></textarea></div>
          <button class="btn btn-primary" onclick="publishInfo()">📢 Publier l'annonce</button>
        </div>
      </div>
      <div class="topbar-title mb-20" style="margin-top:28px;">Annonces publiées</div>
      <div id="publishedInfos"></div>
    </div>

  </div>
</div>

<!-- MODAL EDT -->
<div class="modal-overlay" id="modalEDT">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">📅 Nouveau créneau</span><button class="modal-close" onclick="closeModal('modalEDT')">✕</button></div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Cours</label><select class="form-control"><option>Base de Données</option><option>Web PHP</option><option>UML</option></select></div>
      <div class="form-group"><label class="form-label">Classe</label><select class="form-control"><option>GL3-A</option><option>GL3-B</option><option>GL2-A</option></select></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Jour</label><select class="form-control"><option>Lundi</option><option>Mardi</option><option>Mercredi</option><option>Jeudi</option><option>Vendredi</option><option>Samedi</option></select></div>
        <div class="form-group"><label class="form-label">Salle</label><input type="text" class="form-control" placeholder="S.101"></div>
      </div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Début</label><input type="time" class="form-control" value="08:00"></div>
        <div class="form-group"><label class="form-label">Fin</label><input type="time" class="form-control" value="10:00"></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('modalEDT')">Annuler</button>
      <button class="btn btn-primary" onclick="closeModal('modalEDT');showToast('Créneau ajouté !','success')">✅ Enregistrer</button>
    </div>
  </div>
</div>

<script src="../js/app.js"></script>
<script>
const pages=['dashboard','etudiants','emplois','notes','absences','cours','statistiques','infos'];
function showPage(page){
  pages.forEach(p=>{const el=document.getElementById('page-'+p);if(el)el.style.display=p===page?'':'none';});
  const titles={dashboard:'Tableau de bord',etudiants:'Liste des Étudiants',emplois:'Emplois du Temps',notes:'Notes & Validation',absences:'Gestion des Absences',cours:'Gestion des Cours',statistiques:'Statistiques',infos:'Informations'};
  document.getElementById('pageTitle').textContent=titles[page]||page;
  document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
  if(page==='etudiants')renderEtudiants();
  if(page==='emplois')renderEDT();
  if(page==='notes')renderNotes();
  if(page==='absences')renderAbsences();
  if(page==='statistiques')renderStats();
  document.querySelector('.sidebar')?.classList.remove('open');
}

const etudiants=[
  {nom:'YAO Adjoua Victoire',classe:'GL3-A',moy:14.2,presence:96},
  {nom:'TRAORÉ Ibrahim',classe:'GL3-A',moy:12.0,presence:88},
  {nom:"N'GUESSAN Marie",classe:'GL3-A',moy:15.5,presence:100},
  {nom:'KOUASSI Paul',classe:'GL3-B',moy:13.8,presence:92},
  {nom:'BAMBA Aminata',classe:'GL3-B',moy:16.1,presence:98},
  {nom:'DIALLO Seydou',classe:'GL2-A',moy:11.5,presence:80},
  {nom:'FOFANA Mariam',classe:'GL2-A',moy:9.5,presence:75},
];

function renderEtudiants(){
  document.getElementById('etuBody').innerHTML=etudiants.map((e,i)=>`
    <tr><td>${i+1}</td>
    <td><div style="display:flex;align-items:center;gap:10px;"><div style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#8B1A1A,#D4AF37);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:white;flex-shrink:0;">${e.nom[0]}</div><span>${e.nom}</span></div></td>
    <td><span class="badge badge-info">${e.classe}</span></td>
    <td><strong style="color:${e.moy>=14?'#22c55e':e.moy>=10?'#eab308':'#ef4444'}">${e.moy}/20</strong></td>
    <td><div class="flex-center gap-8"><div class="progress" style="width:60px;"><div class="progress-bar" style="width:${e.presence}%;"></div></div><span>${e.presence}%</span></div></td>
    <td><span class="badge ${e.moy>=10?'badge-success':'badge-danger'}">${e.moy>=10?'✓ Admis':'✗ Ajourné'}</span></td>
    </tr>`).join('');
}

function filterEtu(){
  const q=document.getElementById('searchEtu').value.toLowerCase();
  document.querySelectorAll('#etuBody tr').forEach(r=>r.style.display=r.textContent.toLowerCase().includes(q)?'':'none');
}

const edtData=[
  {jour:'Lundi',debut:'08:00',fin:'10:00',cours:'BD',salle:'S.101',classe:'GL3-A'},
  {jour:'Mercredi',debut:'10:00',fin:'12:00',cours:'Web PHP',salle:'S.102',classe:'GL3-B'},
  {jour:'Vendredi',debut:'14:00',fin:'16:00',cours:'UML',salle:'S.103',classe:'GL3-A'},
];

function renderEDT(){
  const jours=['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
  const heures=['07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00'];
  let html='';
  heures.forEach((h,i)=>{
    if(i>=heures.length-1)return;
    const hFin=heures[i+1];
    html+=`<tr><td style="color:var(--text-muted);font-size:12px;">${h}–${hFin}</td>`;
    jours.forEach(j=>{
      const slot=edtData.find(e=>e.jour===j&&e.debut<=h&&e.fin>=hFin);
      html+=`<td style="padding:4px;">`;
      if(slot)html+=`<div class="schedule-cell"><div class="subject">${slot.cours}</div><div class="teacher">${slot.classe}</div><div class="room">${slot.salle}</div></div>`;
      html+=`</td>`;
    });
    html+='</tr>';
  });
  document.getElementById('edtRespBody').innerHTML=html;
}

const notesData=[
  {etudiant:'YAO Adjoua',matiere:'BD',note:14.5,ens:'COULIBALY JP',valide:false},
  {etudiant:'TRAORÉ Ibrahim',matiere:'BD',note:12.0,ens:'COULIBALY JP',valide:true},
  {etudiant:"N'GUESSAN Marie",matiere:'PHP',note:15.5,ens:'COULIBALY JP',valide:false},
];

function renderNotes(){
  document.getElementById('notesRespBody').innerHTML=notesData.map((n,i)=>`
    <tr>
      <td>${n.etudiant}</td><td>${n.matiere}</td>
      <td><strong style="color:${n.note>=14?'#22c55e':n.note>=10?'#eab308':'#ef4444'}">${n.note}/20</strong></td>
      <td>${n.ens}</td>
      <td><span class="badge ${n.valide?'badge-success':'badge-warning'}">${n.valide?'✓ Validée':'⏳ En attente'}</span></td>
      <td><button class="btn btn-outline btn-sm" onclick="validateNote(${i})">${n.valide?'❌ Révoquer':'✅ Valider'}</button></td>
    </tr>`).join('');
}

function validateNote(i){ notesData[i].valide=!notesData[i].valide; renderNotes(); showToast(`Note ${notesData[i].valide?'validée':'révoquée'} !`,'success'); }
function validateAll(){ notesData.forEach(n=>n.valide=true); renderNotes(); showToast('Toutes les notes ont été validées !','success'); }

const absData=[
  {etudiant:'YAO Adjoua',classe:'GL3-A',date:'2024-01-06',cours:'PHP',statut:'absent',justifiee:false},
  {etudiant:'TRAORÉ Ibrahim',classe:'GL3-A',date:'2024-01-08',cours:'UML',statut:'retard',justifiee:true},
  {etudiant:"N'GUESSAN Marie",classe:'GL3-A',date:'2024-01-10',cours:'BD',statut:'absent',justifiee:false},
];

function renderAbsences(){
  document.getElementById('absRespBody').innerHTML=absData.map((a,i)=>`
    <tr>
      <td>${a.etudiant}</td><td>${a.classe}</td><td>${a.date}</td><td>${a.cours}</td>
      <td><span class="badge ${a.statut==='absent'?'badge-danger':'badge-warning'}">${a.statut}</span></td>
      <td><span class="badge ${a.justifiee?'badge-success':'badge-danger'}">${a.justifiee?'Oui':'Non'}</span></td>
      <td><button class="btn btn-outline btn-sm" onclick="toggleJust(${i})">${a.justifiee?'❌ Annuler':'✅ Justifier'}</button></td>
    </tr>`).join('');
}
function toggleJust(i){ absData[i].justifiee=!absData[i].justifiee; renderAbsences(); showToast('Statut mis à jour','success'); }

let infos=[];
function publishInfo(){
  const titre=document.getElementById('infoTitre').value.trim();
  const contenu=document.getElementById('infoContenu').value.trim();
  if(!titre||!contenu){showToast('Veuillez remplir tous les champs','error');return;}
  infos.unshift({titre,contenu,date:new Date().toLocaleDateString('fr-FR')});
  document.getElementById('infoTitre').value='';
  document.getElementById('infoContenu').value='';
  renderInfos();
  showToast('Annonce publiée !','success');
}
function renderInfos(){
  document.getElementById('publishedInfos').innerHTML=infos.map(i=>`
    <div class="card mb-20"><div class="card-body">
      <div class="flex-between" style="margin-bottom:8px;"><strong style="font-family:Playfair Display,serif;">${i.titre}</strong><span style="font-size:12px;color:var(--text-muted);">${i.date}</span></div>
      <p style="color:var(--text-secondary);font-size:14px;">${i.contenu}</p>
    </div></div>`).join('') || '<div class="empty-state"><div class="empty-icon">📢</div><p>Aucune annonce publiée</p></div>';
}

function renderStats(){
  setTimeout(()=>{
    drawBarChart('chartStatNotes',['BD','PHP','UML','Algo','Réseaux'],[13.8,15.1,12.6,13.2,14.5],'#1a4080');
    drawBarChart('chartStatAbs',['Sep','Oct','Nov','Déc','Jan'],[5,8,3,12,7],'#8B1A1A');
  },100);
}

setTimeout(()=>{ drawBarChart('chartResp',['GL3-A','GL3-B','GL2-A'],[14.2,15.6,12.8],'#1a4080'); },200);
</script>
</body>
</html>
