<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>UIYA — Espace Étudiant</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-icon">U</div><div class="logo-text"><div class="name">UIYA</div><div class="sub">Espace Étudiant</div></div></div>
  <div class="sidebar-user">
    <div class="user-avatar" style="background:linear-gradient(135deg,#3b82f6,#22c55e);">Y</div>
    <div class="user-info"><div class="user-name">YAO Adjoua Victoire</div><div class="user-role" style="color:#3b82f6;">GL3-A · 2020-2021</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-title">Mon Espace</div>
    <a class="nav-item active" data-page="dashboard" onclick="showPage('dashboard')"><span class="icon">🏠</span> Tableau de bord</a>
    <a class="nav-item" data-page="notes" onclick="showPage('notes')"><span class="icon">📝</span> Mes Notes</a>
    <a class="nav-item" data-page="bulletin" onclick="showPage('bulletin')"><span class="icon">📄</span> Mon Bulletin</a>
    <a class="nav-item" data-page="emplois" onclick="showPage('emplois')"><span class="icon">📅</span> Emploi du temps</a>
    <a class="nav-item" data-page="absences" onclick="showPage('absences')"><span class="icon">📋</span> Mes Absences</a>
    <a class="nav-item" data-page="infos" onclick="showPage('infos')"><span class="icon">📢</span> Informations</a>
  </nav>
  <div class="sidebar-footer"><a class="nav-item" href="../index.html"><span class="icon">🚪</span> Déconnexion</a></div>
</aside>

<div class="main-content">
  <header class="topbar">
    <div class="topbar-left">
      <button class="topbar-btn hamburger" onclick="toggleSidebar()">☰</button>
      <div><div class="topbar-title" id="pageTitle">Tableau de bord</div><div class="topbar-subtitle">Bienvenue, Adjoua Victoire 👋</div></div>
    </div>
    <div class="topbar-right">
      <a class="topbar-btn">🔔</a>
      <a class="topbar-btn" href="../index.html">🚪</a>
    </div>
  </header>

  <div class="page-content">

    <!-- DASHBOARD -->
    <div id="page-dashboard">
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-icon">📝</div><div class="stat-value" style="color:#D4AF37;">14.2</div><div class="stat-label">Moyenne générale</div><div class="stat-change up">↑ +0.8 vs T1</div></div>
        <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value" style="color:#22c55e;font-size:24px;">96%</div><div class="stat-label">Taux de présence</div><div class="stat-change up">↑ Excellent</div></div>
        <div class="stat-card"><div class="stat-icon">📚</div><div class="stat-value" data-counter="8">8</div><div class="stat-label">Matières suivies</div><div class="stat-change neutral">Semestre 1</div></div>
        <div class="stat-card"><div class="stat-icon">🏆</div><div class="stat-value" style="color:#D4AF37;">3ème</div><div class="stat-label">Classement classe</div><div class="stat-change up">↑ +2 positions</div></div>
      </div>

      <div class="grid-2 mb-20">
        <div class="card">
          <div class="card-header"><span class="card-title">📊 Évolution de mes notes</span></div>
          <div class="card-body"><canvas id="chartNotesEtu" style="width:100%;height:200px;display:block;"></canvas></div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title">📅 Prochain cours</span></div>
          <div class="card-body">
            <div id="nextCours"></div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">📢 Annonces récentes</span></div>
        <div class="card-body" id="annoncesList"></div>
      </div>
    </div>

    <!-- NOTES -->
    <div id="page-notes" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Mes Notes</div><div class="topbar-subtitle">Trimestre 1 – Année 2020-2021</div></div>
        <select class="form-control" style="width:160px;padding:9px 12px;font-size:13px;" id="selectTrim" onchange="renderNotes()">
          <option value="1">Trimestre 1</option><option value="2">Trimestre 2</option><option value="3">Trimestre 3</option>
        </select>
      </div>
      <div class="card mb-20">
        <div class="card-body" style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;text-align:center;">
          <div><div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#D4AF37;">14.2</div><div style="font-size:12px;color:var(--text-muted);">Moyenne générale</div></div>
          <div><div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#22c55e;">16</div><div style="font-size:12px;color:var(--text-muted);">Meilleure note</div></div>
          <div><div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#ef4444;">12</div><div style="font-size:12px;color:var(--text-muted);">Note la plus basse</div></div>
          <div><div style="font-family:Playfair Display,serif;font-size:28px;font-weight:700;color:#3b82f6;">3ème</div><div style="font-size:12px;color:var(--text-muted);">Classement</div></div>
        </div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Matière</th><th>Enseignant</th><th>Note /20</th><th>Coefficient</th><th>Note pondérée</th><th>Appréciation</th></tr></thead>
            <tbody id="notesEtuBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- BULLETIN -->
    <div id="page-bulletin" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Mon Bulletin</div><div class="topbar-subtitle">Relevé de notes officiel</div></div>
        <button class="btn btn-primary" onclick="printBulletin()">🖨️ Imprimer le bulletin</button>
      </div>
      <div class="card" id="bulletinCard" style="max-width:800px;margin:0 auto;">
        <div style="padding:30px;border-bottom:3px solid var(--secondary);">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
              <div style="font-family:Playfair Display,serif;font-size:22px;font-weight:700;">Université Internationale de Yamoussoukro</div>
              <div style="color:var(--text-muted);font-size:13px;margin-top:4px;">UIYA — Bulletin de Notes Officiel</div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:28px;font-weight:900;font-family:Playfair Display,serif;color:var(--secondary);">U</div>
              <div style="font-size:10px;color:var(--gold);letter-spacing:2px;">UIYA</div>
            </div>
          </div>
        </div>
        <div style="padding:20px 30px;display:grid;grid-template-columns:1fr 1fr;gap:12px;border-bottom:1px solid var(--border);">
          <div><span style="color:var(--text-muted);font-size:12px;">NOM COMPLET</span><div style="font-weight:600;margin-top:2px;">YAO Adjoua Victoire</div></div>
          <div><span style="color:var(--text-muted);font-size:12px;">MATRICULE</span><div style="font-weight:600;margin-top:2px;">UIYA-2021-GL-004</div></div>
          <div><span style="color:var(--text-muted);font-size:12px;">FILIÈRE</span><div style="font-weight:600;margin-top:2px;">Génie Logiciel — Licence 3</div></div>
          <div><span style="color:var(--text-muted);font-size:12px;">CLASSE</span><div style="font-weight:600;margin-top:2px;">GL3-A</div></div>
          <div><span style="color:var(--text-muted);font-size:12px;">ANNÉE SCOLAIRE</span><div style="font-weight:600;margin-top:2px;">2020-2021</div></div>
          <div><span style="color:var(--text-muted);font-size:12px;">TRIMESTRE</span><div style="font-weight:600;margin-top:2px;">Trimestre 1</div></div>
        </div>
        <div style="padding:20px 30px;">
          <table style="width:100%;">
            <thead><tr style="background:rgba(139,26,26,0.15);">
              <th style="padding:10px;text-align:left;font-size:12px;color:var(--text-muted);">MATIÈRE</th>
              <th style="padding:10px;text-align:center;font-size:12px;color:var(--text-muted);">NOTE /20</th>
              <th style="padding:10px;text-align:center;font-size:12px;color:var(--text-muted);">COEFF.</th>
              <th style="padding:10px;text-align:center;font-size:12px;color:var(--text-muted);">PONDÉRÉ</th>
              <th style="padding:10px;text-align:left;font-size:12px;color:var(--text-muted);">APPRÉCIATION</th>
            </tr></thead>
            <tbody id="bulletinBody"></tbody>
            <tfoot>
              <tr style="border-top:2px solid var(--secondary);">
                <td colspan="2" style="padding:12px 10px;font-weight:600;">MOYENNE GÉNÉRALE</td>
                <td style="padding:12px 10px;text-align:center;font-weight:600;" id="bulletinTotalCoeff"></td>
                <td style="padding:12px 10px;text-align:center;font-family:Playfair Display,serif;font-size:20px;font-weight:700;color:#D4AF37;" id="bulletinMoyenne"></td>
                <td style="padding:12px 10px;" id="bulletinMention"></td>
              </tr>
            </tfoot>
          </table>
        </div>
        <div style="padding:16px 30px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
          <div style="font-size:12px;color:var(--text-muted);">Yamoussoukro, le <?php echo date('d/m/Y'); ?></div>
          <div style="text-align:right;font-size:12px;color:var(--text-muted);">Signature du Directeur<div style="height:40px;"></div>Dr. NAPON Abdel Aziz</div>
        </div>
      </div>
    </div>

    <!-- EMPLOI DU TEMPS -->
    <div id="page-emplois" style="display:none;">
      <div class="topbar-title mb-20">Mon Emploi du Temps — GL3-A</div>
      <div class="card">
        <div class="table-wrapper">
          <table class="schedule-table">
            <thead><tr><th style="width:80px;">Horaire</th><th>Lundi</th><th>Mardi</th><th>Mercredi</th><th>Jeudi</th><th>Vendredi</th><th>Samedi</th></tr></thead>
            <tbody id="edtEtuBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ABSENCES -->
    <div id="page-absences" style="display:none;">
      <div class="topbar-title mb-20">Mes Absences</div>
      <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px;">
        <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value" style="font-size:24px;color:#22c55e;">96%</div><div class="stat-label">Taux de présence</div></div>
        <div class="stat-card"><div class="stat-icon">❌</div><div class="stat-value" style="font-size:24px;color:#ef4444;">2</div><div class="stat-label">Absences</div></div>
        <div class="stat-card"><div class="stat-icon">⚠️</div><div class="stat-value" style="font-size:24px;color:#eab308;">1</div><div class="stat-label">Non justifiées</div></div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Date</th><th>Cours</th><th>Horaire</th><th>Statut</th><th>Justifiée</th></tr></thead>
            <tbody id="absEtuBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- INFOS -->
    <div id="page-infos" style="display:none;">
      <div class="topbar-title mb-20">Informations & Annonces</div>
      <div id="infosList"></div>
    </div>

  </div>
</div>

<script src="../js/app.js"></script>
<script src="../js/api.js"></script>
<script>
const notesData = [
  {matiere:'Base de Données',enseignant:'COULIBALY JP',note:14.5,coeff:3,appreciation:'Assez Bien'},
  {matiere:'Développement Web PHP',enseignant:'COULIBALY JP',note:16,coeff:2,appreciation:'Bien'},
  {matiere:'UML & Modélisation',enseignant:'COULIBALY JP',note:13,coeff:3,appreciation:'Assez Bien'},
  {matiere:'Algorithmique',enseignant:'DIALLO A.',note:12,coeff:2,appreciation:'Passable'},
  {matiere:'Réseaux informatiques',enseignant:'KONE F.',note:15,coeff:2,appreciation:'Bien'},
  {matiere:'Anglais des affaires',enseignant:'SMITH J.',note:17,coeff:1,appreciation:'Très Bien'},
];

const edtData = [
  {jour:'Lundi',debut:'08:00',fin:'10:00',cours:'Base de Données',salle:'S.101',enseignant:'COULIBALY JP'},
  {jour:'Lundi',debut:'10:00',fin:'12:00',cours:'UML & Modélisation',salle:'S.201',enseignant:'COULIBALY JP'},
  {jour:'Mercredi',debut:'08:00',fin:'10:00',cours:'Algorithmique',salle:'S.301',enseignant:'DIALLO A.'},
  {jour:'Mercredi',debut:'14:00',fin:'16:00',cours:'Développement Web PHP',salle:'S.102',enseignant:'COULIBALY JP'},
  {jour:'Vendredi',debut:'10:00',fin:'12:00',cours:'Réseaux informatiques',salle:'S.401',enseignant:'KONE F.'},
  {jour:'Vendredi',debut:'14:00',fin:'15:00',cours:'Anglais des affaires',salle:'S.201',enseignant:'SMITH J.'},
];

const absData = [
  {date:'2021-01-06',cours:'Développement Web PHP',horaire:'10:00-12:00',statut:'absent',justifiee:false},
  {date:'2021-01-20',cours:'Anglais des affaires',horaire:'14:00-15:00',statut:'retard',justifiee:true},
];

const pages=['dashboard','notes','bulletin','emplois','absences','infos'];
function showPage(page){
  pages.forEach(p=>{const el=document.getElementById('page-'+p);if(el)el.style.display=p===page?'':'none';});
  document.getElementById('pageTitle').textContent={dashboard:'Tableau de bord',notes:'Mes Notes',bulletin:'Mon Bulletin',emplois:'Emploi du Temps',absences:'Mes Absences',infos:'Informations'}[page]||page;
  document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
  if(page==='notes')renderNotes();
  if(page==='bulletin')renderBulletin();
  if(page==='emplois')renderEDT();
  if(page==='absences')renderAbsences();
  if(page==='infos')renderInfos();
  document.querySelector('.sidebar')?.classList.remove('open');
}

async function renderNotes(){
  const apiRes = await NoteAPI.liste({trimestre: document.getElementById('selectTrim')?.value||''});
  const notes = (apiRes && apiRes.success) ? apiRes.data : notesData.map(n=>({
    matiere:n.matiere,nom_enseignant:n.enseignant,valeur:n.note,coefficient:n.coeff,appreciation:n.appreciation
  }));
  document.getElementById('notesEtuBody').innerHTML=notes.map(n=>{
    const v = parseFloat(n.valeur||n.note);
    const ens = n.nom_enseignant||n.enseignant||'—';
    const appr = n.appreciation||'';
    const coeff = n.coefficient||n.coeff||1;
    return`<tr>
      <td><strong style="color:var(--text-primary)">${n.matiere}</strong></td>
      <td>${ens}</td>
      <td><strong style="color:${v>=14?'#22c55e':v>=10?'#eab308':'#ef4444'};font-size:16px;">${v}/20</strong></td>
      <td>${coeff}</td>
      <td>${(v*coeff).toFixed(2)}</td>
      <td><span class="badge ${v>=14?'badge-success':v>=10?'badge-warning':'badge-danger'}">${appr}</span></td>
    </tr>`;
  }).join('');
  return; // original map replaced
  document.getElementById('notesEtuBody').innerHTML=notesData.map(n=>{
    const pond=(n.note*n.coeff).toFixed(2);
    return`<tr>
      <td><strong style="color:var(--text-primary)">${n.matiere}</strong></td>
      <td>${n.enseignant}</td>
      <td><strong style="color:${n.note>=14?'#22c55e':n.note>=10?'#eab308':'#ef4444'};font-size:16px;">${n.note}/20</strong></td>
      <td>${n.coeff}</td>
      <td>${pond}</td>
      <td><span class="badge ${n.note>=14?'badge-success':n.note>=10?'badge-warning':'badge-danger'}">${n.appreciation}</span></td>
    </tr>`;
  }).join('');
}

function renderBulletin(){
  let totalPond=0,totalCoeff=0;
  document.getElementById('bulletinBody').innerHTML=notesData.map(n=>{
    const pond=(n.note*n.coeff).toFixed(2);
    totalPond+=n.note*n.coeff; totalCoeff+=n.coeff;
    return`<tr style="border-bottom:1px solid rgba(255,255,255,0.04);">
      <td style="padding:10px;">${n.matiere}</td>
      <td style="padding:10px;text-align:center;font-weight:600;color:${n.note>=14?'#22c55e':n.note>=10?'#eab308':'#ef4444'}">${n.note}</td>
      <td style="padding:10px;text-align:center;">${n.coeff}</td>
      <td style="padding:10px;text-align:center;">${pond}</td>
      <td style="padding:10px;"><span class="badge ${n.note>=14?'badge-success':n.note>=10?'badge-warning':'badge-danger'}">${n.appreciation}</span></td>
    </tr>`;
  }).join('');
  const moy=(totalPond/totalCoeff).toFixed(2);
  document.getElementById('bulletinTotalCoeff').textContent=totalCoeff;
  document.getElementById('bulletinMoyenne').textContent=moy+'/20';
  const mention=moy>=16?'Très Bien':moy>=14?'Bien':moy>=12?'Assez Bien':moy>=10?'Passable':'Insuffisant';
  document.getElementById('bulletinMention').innerHTML=`<span class="badge ${moy>=14?'badge-success':moy>=10?'badge-warning':'badge-danger'}">${mention}</span>`;
}

async function renderEDT(){
  const apiRes = await EmploiAPI.liste();
  const slots = (apiRes && apiRes.success) ? apiRes.data.map(e=>({
    jour:e.jour, debut:e.heur_debut?.substring(0,5), fin:e.heur_fin?.substring(0,5),
    cours:e.intitule||e.matiere, enseignant:e.nom_enseignant, salle:e.salle||'—'
  })) : edtData;
  const jours=['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
  const heures=['07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00'];
  let html='';
  heures.forEach((h,i)=>{
    if(i>=heures.length-1)return;
    const hFin=heures[i+1];
    html+=`<tr><td style="color:var(--text-muted);font-size:12px;white-space:nowrap;">${h}–${hFin}</td>`;
    jours.forEach(j=>{
      const slot=slots.find(e=>e.jour===j&&e.debut<=h&&e.fin>=hFin);
      html+=`<td style="padding:4px;">`;
      if(slot)html+=`<div class="schedule-cell"><div class="subject">${slot.cours}</div><div class="teacher">${slot.enseignant}</div><div class="room">${slot.salle}</div></div>`;
      html+=`</td>`;
    });
    html+='</tr>';
  });
  document.getElementById('edtEtuBody').innerHTML=html;
}

async function renderAbsences(){
  const apiRes = await AbsenceAPI.liste();
  const data = (apiRes && apiRes.success) ? apiRes.data.map(a=>({
    date:a.datepresence, cours:a.intitule||a.matiere,
    horaire:(a.heur_debut||'')+'–'+(a.heur_fin||''),
    statut:a.statut, justifiee:!!parseInt(a.justifiee)
  })) : absData;
  document.getElementById('absEtuBody').innerHTML=data.map(a=>`
    <tr>
      <td>${a.date}</td><td>${a.cours}</td><td>${a.horaire}</td>
      <td><span class="badge ${a.statut==='absent'?'badge-danger':'badge-warning'}">${a.statut==='absent'?'❌ Absent':'⚠️ Retard'}</span></td>
      <td><span class="badge ${a.justifiee?'badge-success':'badge-danger'}">${a.justifiee?'✓ Oui':'✗ Non'}</span></td>
    </tr>`).join('');
}

function renderInfos(){
  const annonces=[
    {titre:'Examens de fin de semestre',date:'15 Jan 2021',corps:'Les examens du Trimestre 1 débuteront le 20 janvier 2021. Consultez votre emploi du temps pour les détails.',icone:'📋'},
    {titre:'Sortie pédagogique',date:'10 Jan 2021',corps:'Une sortie pédagogique est organisée le 25 janvier au parc technologique de Yamoussoukro.',icone:'🚌'},
    {titre:'Inscription aux UV du S2',date:'05 Jan 2021',corps:'Les inscriptions aux unités de valeur du Semestre 2 sont ouvertes jusqu\'au 31 janvier.',icone:'📝'},
  ];
  document.getElementById('infosList').innerHTML=annonces.map(a=>`
    <div class="card mb-20"><div class="card-body">
      <div style="display:flex;align-items:flex-start;gap:16px;">
        <div style="font-size:32px;">${a.icone}</div>
        <div style="flex:1;">
          <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
            <strong style="font-family:Playfair Display,serif;font-size:16px;">${a.titre}</strong>
            <span style="font-size:12px;color:var(--text-muted);">${a.date}</span>
          </div>
          <p style="color:var(--text-secondary);font-size:14px;line-height:1.6;">${a.corps}</p>
        </div>
      </div>
    </div></div>`).join('');
}

function printBulletin(){
  showPage('bulletin');
  setTimeout(()=>window.print(),300);
}

// Dashboard init
document.getElementById('nextCours').innerHTML=`
  <div style="display:flex;flex-direction:column;gap:10px;">
  ${edtData.slice(0,3).map(e=>`
    <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
      <div style="background:linear-gradient(135deg,#8B1A1A,#C0392B);border-radius:8px;padding:8px 12px;font-size:12px;font-weight:600;color:white;text-align:center;min-width:60px;">${e.jour}<br><span style="font-size:10px;">${e.debut}</span></div>
      <div><div style="font-size:13px;font-weight:600;color:var(--text-primary);">${e.cours}</div><div style="font-size:12px;color:var(--text-muted);">${e.enseignant} · ${e.salle}</div></div>
    </div>`).join('')}
  </div>`;

document.getElementById('annoncesList').innerHTML=`
  <div style="display:flex;flex-direction:column;gap:10px;">
  <div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.05);"><span style="font-size:20px;">📋</span><div><div style="font-size:13px;font-weight:500;">Examens T1 — du 20 au 28 janvier</div><div style="font-size:11px;color:var(--text-muted);">15 Jan 2021</div></div></div>
  <div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.05);"><span style="font-size:20px;">🚌</span><div><div style="font-size:13px;font-weight:500;">Sortie pédagogique — 25 janvier</div><div style="font-size:11px;color:var(--text-muted);">10 Jan 2021</div></div></div>
  <div style="display:flex;align-items:center;gap:12px;padding:12px 0;"><span style="font-size:20px;">📝</span><div><div style="font-size:13px;font-weight:500;">Inscriptions S2 ouvertes jusqu\'au 31 jan.</div><div style="font-size:11px;color:var(--text-muted);">5 Jan 2021</div></div></div>
  </div>`;

setTimeout(()=>{
  drawBarChart('chartNotesEtu',['BD','PHP','UML','Algo','Réseaux','Anglais'],[14.5,16,13,12,15,17],'#1a4080');
},300);
</script>
</body>
</html>
