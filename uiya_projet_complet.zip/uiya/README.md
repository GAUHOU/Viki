# UIYA — Application Web de Gestion de la Scolarité

## Structure du projet

```
uiya/
├── index.html                    ← Page de connexion principale
├── css/
│   └── style.css                 ← Feuille de style globale (dark theme)
├── js/
│   └── app.js                    ← JavaScript partagé (charts, modals, toasts)
├── includes/
│   └── config.php                ← Configuration BDD & sessions PHP
├── admin/
│   └── dashboard.php             ← Dashboard Administrateur (CRUD complet)
├── responsable/
│   └── dashboard.php             ← Dashboard Responsable de filière
├── enseignant/
│   └── dashboard.php             ← Dashboard Enseignant (notes, absences)
├── etudiant/
│   └── dashboard.php             ← Dashboard Étudiant (notes, bulletin, EDT)
└── parent/
    └── dashboard.php             ← Dashboard Parent (suivi de l'enfant)
```

## Technologies utilisées

| Technologie | Rôle |
|-------------|------|
| HTML5 | Structure des pages |
| CSS3 | Style, animations, responsive |
| JavaScript | Interactivité, graphiques, CRUD local |
| PHP | Backend serveur (prêt pour connexion BDD) |
| MySQL | Base de données (voir uiya_database.sql) |
| XAMPP | Environnement local (Apache + MySQL + PHP) |

## Installation avec XAMPP

1. Copier le dossier `uiya/` dans `C:/xampp/htdocs/`
2. Importer `uiya_database.sql` dans phpMyAdmin
3. Ouvrir `http://localhost/uiya/` dans le navigateur

## Comptes de démonstration

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| Administrateur | admin@uiya.ci | Admin@2024 |
| Responsable | resp.info@uiya.ci | Resp@2024 |
| Enseignant | jp.coulibaly@uiya.ci | Ens@2024 |
| Étudiant | yao.adjoua@uiya.ci | Etu@2024 |
| Parent | kanga.arsene@uiya.ci | Par@2024 |

## Fonctionnalités par rôle

### 🛡️ Administrateur
- Gestion complète des utilisateurs (CRUD)
- Gestion des filières et classes
- Gestion des cours
- Emplois du temps
- Saisie des notes
- Gestion des absences
- Statistiques générales

### 👨‍💼 Responsable de filière
- Liste et suivi des étudiants
- Gestion des emplois du temps
- Validation des notes
- Gestion des absences
- Statistiques de la filière
- Publication d'informations

### 👨‍🏫 Enseignant
- Consultation de son emploi du temps
- Saisie en masse des notes
- Enregistrement des absences
- Vue des performances des classes

### 🎓 Étudiant
- Tableau de bord personnel
- Consultation des notes par trimestre
- Bulletin de notes (imprimable)
- Emploi du temps
- Historique des absences
- Annonces de l'établissement

### 👨‍👧 Parent
- Suivi complet de son enfant
- Consultation des notes et bulletins
- Emploi du temps de l'enfant
- Suivi des absences
- Informations de l'établissement

## Notes techniques

- L'application fonctionne en mode démo (localStorage) sans serveur
- Pour la production : connecter includes/config.php à la base MySQL
- Design responsive (mobile, tablette, desktop)
- Thème sombre élégant avec palette rouge/or UIYA
