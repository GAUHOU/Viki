<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('administrateur','responsable','enseignant','etudiant','parent');

$db = getDB(); $method = $_SERVER['REQUEST_METHOD']; $input = getInput();

// ── GET ──────────────────────────────────────────
if ($method === 'GET') {
    $etuId     = $input['id_ed']     ?? null;
    $classeId  = $input['id_cl']     ?? null;
    $coursId   = $input['idcours']   ?? null;
    $trimestre = $input['trimestre'] ?? null;
    $annee     = $input['annee']     ?? null;

    // Restreindre selon rôle
    if ($_SESSION['user_type']==='etudiant') {
        // Récupérer id_ed de l'étudiant connecté
        $stmt=$db->prepare("SELECT id_ed FROM etudiant WHERE id_utilisateur=?");
        $stmt->execute([$_SESSION['user_id']]); $etu=$stmt->fetch();
        if (!$etu) jsonResponse(['success'=>false,'message'=>'Profil étudiant introuvable'],404);
        $etuId=$etu['id_ed'];
    }
    if ($_SESSION['user_type']==='parent') {
        // Récupérer les enfants de ce parent
        $stmt=$db->prepare("SELECT pe.id_ed FROM parent_etudiant pe JOIN parent p ON p.idParent=pe.idParent WHERE p.id_utilisateur=?");
        $stmt->execute([$_SESSION['user_id']]); $enfants=$stmt->fetchAll(PDO::FETCH_COLUMN);
        if ($etuId && !in_array($etuId,$enfants)) jsonResponse(['success'=>false,'message'=>'Accès refusé'],403);
        if (!$etuId && $enfants) $etuId=$enfants[0];
    }

    $sql = "SELECT n.*,
                   CONCAT(u.nom,' ',u.prenoms) AS nom_etudiant,
                   c.nom_cl,co.intitule,co.matiere,
                   ex.libelle AS examen_libelle
            FROM note n
            JOIN etudiant e ON e.id_ed=n.id_ed
            JOIN utilisateur u ON u.id_utilisateur=e.id_utilisateur
            JOIN classe c ON c.id_cl=e.id_cl
            JOIN cours co ON co.idcours=n.idcours
            LEFT JOIN examen ex ON ex.idexam=n.idexam
            WHERE 1=1";
    $params=[];
    if ($etuId)    { $sql.=" AND n.id_ed=?";      $params[]=$etuId; }
    if ($classeId) { $sql.=" AND c.id_cl=?";      $params[]=$classeId; }
    if ($coursId)  { $sql.=" AND n.idcours=?";    $params[]=$coursId; }
    if ($trimestre){ $sql.=" AND n.trimestre=?";  $params[]=$trimestre; }
    if ($annee)    { $sql.=" AND ex.annee_scolaire=?"; $params[]=$annee; }
    $sql .= " ORDER BY u.nom,u.prenoms,co.matiere";
    $stmt=$db->prepare($sql); $stmt->execute($params);
    $notes=$stmt->fetchAll();

    // Ajouter calcul appréciation auto
    foreach ($notes as &$n) {
        $v=(float)$n['valeur'];
        if (!$n['appreciation']) {
            $n['appreciation'] = $v>=16?'Très Bien':($v>=14?'Bien':($v>=12?'Assez Bien':($v>=10?'Passable':'Insuffisant')));
        }
    }
    jsonResponse(['success'=>true,'data'=>$notes]);
}

// ── POST — Créer / Saisir une note ───────────────
if ($method === 'POST') {
    requireRole('administrateur','responsable','enseignant');
    $etuId     = (int)($input['id_ed']    ?? 0);
    $examenId  = (int)($input['idexam']   ?? 0);
    $coursId   = (int)($input['idcours']  ?? 0);
    $valeur    = (float)($input['valeur'] ?? -1);
    $coeff     = (float)($input['coefficient'] ?? 1);
    $trimestre = (int)($input['trimestre'] ?? 1);
    $appreciation = sanitize($input['appreciation'] ?? '');

    if (!$etuId || $valeur<0 || $valeur>20 || !$coursId || !$trimestre)
        jsonResponse(['success'=>false,'message'=>'Données invalides (note entre 0 et 20 requise)'],400);

    // Appréciation automatique si non fournie
    if (!$appreciation) {
        $appreciation = $valeur>=16?'Très Bien':($valeur>=14?'Bien':($valeur>=12?'Assez Bien':($valeur>=10?'Passable':'Insuffisant')));
    }

    // Vérifier si note déjà existante pour cet étudiant/cours/trimestre
    $check=$db->prepare("SELECT idnote FROM note WHERE id_ed=? AND idcours=? AND trimestre=?");
    $check->execute([$etuId,$coursId,$trimestre]);
    if ($existing=$check->fetch()) {
        // Mettre à jour au lieu d'insérer
        $db->prepare("UPDATE note SET valeur=?,coefficient=?,appreciation=?,moyenne=? WHERE idnote=?")
           ->execute([$valeur,$coeff,$appreciation,$valeur,$existing['idnote']]);
        jsonResponse(['success'=>true,'message'=>'Note mise à jour','id'=>$existing['idnote']]);
    }

    $db->prepare("INSERT INTO note (valeur,coefficient,trimestre,appreciation,moyenne,id_ed,idexam,idcours) VALUES (?,?,?,?,?,?,?,?)")
       ->execute([$valeur,$coeff,$trimestre,$appreciation,$valeur,$etuId,$examenId?:null,$coursId]);
    jsonResponse(['success'=>true,'message'=>'Note enregistrée','id'=>$db->lastInsertId()],201);
}

// ── PUT ──────────────────────────────────────────
if ($method === 'PUT') {
    requireRole('administrateur','responsable','enseignant');
    $id=(int)($input['id']??0); $valeur=(float)($input['valeur']??-1); $coeff=(float)($input['coefficient']??1); $trimestre=(int)($input['trimestre']??1);
    $appreciation=sanitize($input['appreciation']??'');
    if (!$id||$valeur<0||$valeur>20) jsonResponse(['success'=>false,'message'=>'Données invalides'],400);
    if (!$appreciation) $appreciation=$valeur>=16?'Très Bien':($valeur>=14?'Bien':($valeur>=12?'Assez Bien':($valeur>=10?'Passable':'Insuffisant')));
    $db->prepare("UPDATE note SET valeur=?,coefficient=?,trimestre=?,appreciation=?,moyenne=? WHERE idnote=?")->execute([$valeur,$coeff,$trimestre,$appreciation,$valeur,$id]);
    jsonResponse(['success'=>true,'message'=>'Note modifiée']);
}

// ── DELETE ───────────────────────────────────────
if ($method === 'DELETE') {
    requireRole('administrateur');
    $id=(int)($input['id']??0); if (!$id) jsonResponse(['success'=>false,'message'=>'ID manquant'],400);
    $db->prepare("DELETE FROM note WHERE idnote=?")->execute([$id]);
    jsonResponse(['success'=>true,'message'=>'Note supprimée']);
}

// ── GET MOYENNE — endpoint spécial /api/notes.php?action=moyenne ──
if ($_SERVER['REQUEST_METHOD']==='GET' && ($input['action']??'')==='moyenne') {
    $etuId=(int)($input['id_ed']??0); $trimestre=$input['trimestre']??null;
    if (!$etuId) jsonResponse(['success'=>false,'message'=>'ID étudiant requis'],400);
    $sql="SELECT SUM(n.valeur*n.coefficient)/SUM(n.coefficient) AS moyenne_generale,
                 COUNT(*) AS nb_notes
          FROM note n WHERE n.id_ed=?";
    $params=[$etuId];
    if ($trimestre) { $sql.=" AND n.trimestre=?"; $params[]=$trimestre; }
    $stmt=$db->prepare($sql); $stmt->execute($params); $r=$stmt->fetch();
    jsonResponse(['success'=>true,'data'=>['moyenne'=>round($r['moyenne_generale']??0,2),'nb_notes'=>$r['nb_notes']]]);
}
?>
