<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('administrateur','responsable','enseignant','etudiant','parent');

$db = getDB(); $method = $_SERVER['REQUEST_METHOD']; $input = getInput();

if ($method === 'GET') {
    $filiereId = $input['id_filiere'] ?? null;
    $classeId  = $input['id_cl']      ?? null;
    $ensId     = $input['id_ens']     ?? null;

    $sql = "SELECT edt.*,f.nom_filiere,c.nom_cl,
                   co.intitule,co.matiere,
                   CONCAT(u.nom,' ',u.prenoms) AS nom_enseignant
            FROM emploi_du_temps edt
            JOIN filiere f   ON f.id_filiere=edt.id_filiere
            JOIN classe c    ON c.id_cl=edt.id_cl
            JOIN cours co    ON co.idcours=edt.idcours
            JOIN enseignant en ON en.id_ens=edt.id_ens
            JOIN utilisateur u ON u.id_utilisateur=en.id_utilisateur
            WHERE 1=1";
    $params=[];
    if ($filiereId){ $sql.=" AND edt.id_filiere=?"; $params[]=$filiereId; }
    if ($classeId) { $sql.=" AND edt.id_cl=?";      $params[]=$classeId; }
    if ($ensId)    { $sql.=" AND edt.id_ens=?";     $params[]=$ensId; }
    $sql .= " ORDER BY FIELD(edt.jour,'Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'),edt.heur_debut";
    $stmt=$db->prepare($sql); $stmt->execute($params);
    jsonResponse(['success'=>true,'data'=>$stmt->fetchAll()]);
}

if ($method === 'POST') {
    requireRole('administrateur','responsable');
    $filiereId=(int)($input['id_filiere']??0); $classeId=(int)($input['id_cl']??0);
    $coursId=(int)($input['idcours']??0); $ensId=(int)($input['id_ens']??0);
    $jour=sanitize($input['jour']??''); $debut=$input['heur_debut']??''; $fin=$input['heur_fin']??''; $salle=sanitize($input['salle']??'');
    if (!$filiereId||!$classeId||!$coursId||!$jour||!$debut||!$fin) jsonResponse(['success'=>false,'message'=>'Données manquantes'],400);
    if ($debut>=$fin) jsonResponse(['success'=>false,'message'=>'Heure de fin invalide'],400);
    // Vérifier conflit de salle
    $conflict=$db->prepare("SELECT idEmploiDuTemps FROM emploi_du_temps WHERE jour=? AND salle=? AND ((heur_debut<? AND heur_fin>?) OR (heur_debut<? AND heur_fin>?))");
    $conflict->execute([$jour,$salle,$fin,$debut,$fin,$debut]);
    if ($conflict->fetch()) jsonResponse(['success'=>false,'message'=>'Conflit de salle sur ce créneau'],409);
    $db->prepare("INSERT INTO emploi_du_temps (jour,heur_debut,heur_fin,salle,id_filiere,id_cl,idcours,id_ens) VALUES (?,?,?,?,?,?,?,?)")
       ->execute([$jour,$debut,$fin,$salle,$filiereId,$classeId,$coursId,$ensId]);
    jsonResponse(['success'=>true,'message'=>'Créneau ajouté','id'=>$db->lastInsertId()],201);
}

if ($method === 'DELETE') {
    requireRole('administrateur','responsable');
    $id=(int)($input['id']??0); if (!$id) jsonResponse(['success'=>false,'message'=>'ID manquant'],400);
    $db->prepare("DELETE FROM emploi_du_temps WHERE idEmploiDuTemps=?")->execute([$id]);
    jsonResponse(['success'=>true,'message'=>'Créneau supprimé']);
}
?>
