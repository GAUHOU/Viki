<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>UIYA — Espace Enseignant</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-icon">U</div><div class="logo-text"><div class="name">UIYA</div><div class="sub">Espace Enseignant</div></div></div>
  <div class="sidebar-user">
    <div class="user-avatar" style="background:linear-gradient(135deg,#22c55e,#3b82f6);">C</div>
    <div class="user-info"><div class="user-name">COULIBALY Jean-Paul</div><div class="user-role" style="color:#22c55e;">Développement Web & BD</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-title">Mon Espace</div>
    <a class="nav-item active" data-page="dashboard" onclick="showPage('dashboard')"><span class="icon">🏠</span> Tableau de bord</a>
    <a class="nav-item" data-page="emplois" onclick="showPage('emplois')"><span class="icon">📅</span> Mon Emploi du temps</a>
    <a class="nav-item" data-page="classes" onclick="showPage('classes')"><span class="icon">🎓</span> Mes Classes</a>
    <a class="nav-item" data-page="notes" onclick="showPage('notes')"><span class="icon">📝</span> Saisie des Notes</a>
    <a class="nav-item" data-page="absences" onclick="showPage('absences')"><span class="icon">📋</span> Absences</a>
  </nav>
  <div class="sidebar-footer"><a class="nav-item" href="../index.html"><span class="icon">🚪</span> Déconnexion</a></div>
</aside>

<div class="main-content">
  <header class="topbar">
    <div class="topbar-left">
      <button class="topbar-btn hamburger" onclick="toggleSidebar()">☰</button>
      <div><div class="topbar-title" id="pageTitle">Tableau de bord</div><div class="topbar-subtitle">COULIBALY Jean-Paul · Enseignant</div></div>
    </div>
    <div class="topbar-right"><a class="topbar-btn">🔔</a><a class="topbar-btn" href="../index.html">🚪</a></div>
  </header>

  <div class="page-content">

    <!-- DASHBOARD -->
    <div id="page-dashboard">
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-icon">🎓</div><div class="stat-value" data-counter="95">95</div><div class="stat-label">Étudiants suivis</div></div>
        <div class="stat-card"><div class="stat-icon">📚</div><div class="stat-value" data-counter="3">3</div><div class="stat-label">Cours dispensés</div></div>
        <div class="stat-card"><div class="stat-icon">🏫</div><div class="stat-value" data-counter="4">4</div><div class="stat-label">Classes</div></div>
        <div class="stat-card"><div class="stat-icon">📝</div><div class="stat-value" style="color:#D4AF37;">14.1</div><div class="stat-label">Moyenne de classe</div></div>
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="card-header"><span class="card-title">📅 Cours d'aujourd'hui</span></div>
          <div class="card-body" id="todayCours"></div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title">📊 Performance des classes</span></div>
          <div class="card-body"><canvas id="chartClasses" style="width:100%;height:200px;display:block;"></canvas></div>
        </div>
      </div>
    </div>

    <!-- EMPLOI DU TEMPS -->
    <div id="page-emplois" style="display:none;">
      <div class="topbar-title mb-20">Mon Emploi du Temps</div>
      <div class="card">
        <div class="table-wrapper">
          <table class="schedule-table">
            <thead><tr><th style="width:80px;">Horaire</th><th>Lundi</th><th>Mardi</th><th>Mercredi</th><th>Jeudi</th><th>Vendredi</th><th>Samedi</th></tr></thead>
            <tbody id="edtEnsBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- CLASSES -->
    <div id="page-classes" style="display:none;">
      <div class="topbar-title mb-20">Mes Classes</div>
      <div class="grid-2">
        <div class="card"><div class="card-header"><span class="card-title">GL3-A · Base de Données</span><span class="badge badge-info">25 étudiants</span></div>
          <div class="card-body">
            <div class="progress" style="margin-bottom:8px;"><div class="progress-bar" style="width:71%;"></div></div>
            <div style="font-size:13px;color:var(--text-muted);">Moyenne classe : <strong style="color:#D4AF37;">14.2/20</strong></div>
            <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">Taux de réussite : <strong style="color:#22c55e;">88%</strong></div>
            <button class="btn btn-outline btn-sm" style="margin-top:12px;" onclick="showPage('notes')">📝 Saisir les notes</button>
          </div>
        </div>
        <div class="card"><div class="card-header"><span class="card-title">GL3-B · Web PHP</span><span class="badge badge-info">20 étudiants</span></div>
          <div class="card-body">
            <div class="progress" style="margin-bottom:8px;"><div class="progress-bar" style="width:78%;"></div></div>
            <div style="font-size:13px;color:var(--text-muted);">Moyenne classe : <strong style="color:#D4AF37;">15.6/20</strong></div>
            <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">Taux de réussite : <strong style="color:#22c55e;">95%</strong></div>
            <button class="btn btn-outline btn-sm" style="margin-top:12px;" onclick="showPage('notes')">📝 Saisir les notes</button>
          </div>
        </div>
      </div>
    </div>

    <!-- NOTES SAISIE -->
    <div id="page-notes" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Saisie des Notes</div><div class="topbar-subtitle">Saisir ou modifier les notes de vos étudiants</div></div>
        <div class="flex-center gap-8">
          <select class="form-control" style="width:140px;padding:9px;font-size:13px;" id="selClasse" onchange="loadStudents()">
            <option value="GL3-A">GL3-A</option><option value="GL3-B">GL3-B</option>
          </select>
          <select class="form-control" style="width:160px;padding:9px;font-size:13px;" id="selCours">
            <option>Base de Données</option><option>Développement Web PHP</option><option>UML & Modélisation</option>
          </select>
          <select class="form-control" style="width:130px;padding:9px;font-size:13px;" id="selTrim">
            <option value="1">Trimestre 1</option><option value="2">Trimestre 2</option><option value="3">Trimestre 3</option>
          </select>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Liste des étudiants</span>
          <button class="btn btn-primary btn-sm" onclick="saveAllNotes()">💾 Enregistrer toutes les notes</button>
        </div>
        <div class="table-wrapper">
          <table><thead><tr><th>#</th><th>Nom de l'étudiant</th><th>Note /20</th><th>Appréciation</th><th>Statut</th></tr></thead>
            <tbody id="notesEnsBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ABSENCES -->
    <div id="page-absences" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Gestion des Absences</div><div class="topbar-subtitle">Enregistrer les absences pour vos cours</div></div>
        <div class="flex-center gap-8">
          <input type="date" class="form-control" id="absDate" style="padding:9px;font-size:13px;">
          <select class="form-control" style="width:180px;padding:9px;font-size:13px;" id="absCours">
            <option>Base de Données</option><option>Développement Web PHP</option><option>UML & Modélisation</option>
          </select>
          <button class="btn btn-primary" onclick="saveAbsences()">💾 Enregistrer</button>
        </div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>#</th><th>Étudiant</th><th>Statut</th><th>Justifiée</th></tr></thead>
            <tbody id="absEnsBody"></tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="../js/app.js"></script>
<script>
const students = [
  'YAO Adjoua Victoire','TRAORÉ Ibrahim','N\'GUESSAN Marie','KOUASSI Paul','BAMBA Aminata',
  'DIALLO Seydou','FOFANA Mariam','KONÉ Adama','BROU Estelle','AKISSI Cécile'
];

let notesMap = {};

const pages=['dashboard','emplois','classes','notes','absences'];
function showPage(page){
  pages.forEach(p=>{const el=document.getElementById('page-'+p);if(el)el.style.display=p===page?'':'none';});
  document.getElementById('pageTitle').textContent={dashboard:'Tableau de bord',emplois:'Mon Emploi du Temps',classes:'Mes Classes',notes:'Saisie des Notes',absences:'Gestion des Absences'}[page]||page;
  document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
  if(page==='emplois')renderEDT();
  if(page==='notes')loadStudents();
  if(page==='absences')renderAbsenceSheet();
  document.querySelector('.sidebar')?.classList.remove('open');
}

const edtData=[
  {jour:'Lundi',debut:'08:00',fin:'10:00',cours:'Base de Données',salle:'S.101',classe:'GL3-A'},
  {jour:'Mercredi',debut:'10:00',fin:'12:00',cours:'Web PHP',salle:'S.102',classe:'GL3-B'},
  {jour:'Vendredi',debut:'14:00',fin:'16:00',cours:'UML',salle:'S.103',classe:'GL3-A'},
];

function renderEDT(){
  const jours=['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
  const heures=['07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00'];
  let html='';
  heures.forEach((h,i)=>{
    if(i>=heures.length-1)return;
    const hFin=heures[i+1];
    html+=`<tr><td style="color:var(--text-muted);font-size:12px;white-space:nowrap;">${h}–${hFin}</td>`;
    jours.forEach(j=>{
      const slot=edtData.find(e=>e.jour===j&&e.debut<=h&&e.fin>=hFin);
      html+=`<td style="padding:4px;">`;
      if(slot)html+=`<div class="schedule-cell"><div class="subject">${slot.cours}</div><div class="teacher">${slot.classe}</div><div class="room">${slot.salle}</div></div>`;
      html+=`</td>`;
    });
    html+='</tr>';
  });
  document.getElementById('edtEnsBody').innerHTML=html;
}

function loadStudents(){
  document.getElementById('notesEnsBody').innerHTML=students.map((s,i)=>{
    const saved=notesMap[s];
    return`<tr>
      <td>${i+1}</td>
      <td><strong>${s}</strong></td>
      <td><input type="number" min="0" max="20" step="0.25" value="${saved||''}" class="form-control" style="width:90px;padding:8px;" id="note_${i}" oninput="updateAppreciation(${i},this.value)"></td>
      <td id="appr_${i}" style="color:var(--text-muted);">${saved?getAppr(saved):'—'}</td>
      <td id="stat_${i}"><span class="badge ${saved?'badge-success':'badge-warning'}">${saved?'✓ Saisie':'En attente'}</span></td>
    </tr>`;
  }).join('');
}

function getAppr(v){ return v>=16?'Très Bien':v>=14?'Bien':v>=12?'Assez Bien':v>=10?'Passable':'Insuffisant'; }
function updateAppreciation(i,v){
  if(v<0||v>20)return;
  document.getElementById('appr_'+i).textContent=v?getAppr(parseFloat(v)):'—';
  document.getElementById('stat_'+i).innerHTML=`<span class="badge badge-warning">✏️ Modifié</span>`;
}

function saveAllNotes(){
  let saved=0;
  students.forEach((s,i)=>{
    const v=document.getElementById('note_'+i)?.value;
    if(v!==''&&v!==undefined){
      notesMap[s]=parseFloat(v);
      const statEl=document.getElementById('stat_'+i);
      if(statEl)statEl.innerHTML=`<span class="badge badge-success">✓ Sauvegardé</span>`;
      saved++;
    }
  });
  showToast(`${saved} note(s) enregistrée(s) avec succès !`,'success');
}

function renderAbsenceSheet(){
  document.getElementById('absEnsBody').innerHTML=students.map((s,i)=>`
    <tr>
      <td>${i+1}</td><td><strong>${s}</strong></td>
      <td>
        <select class="form-control" id="abs_${i}" style="padding:7px;font-size:13px;">
          <option value="present">✅ Présent</option>
          <option value="absent">❌ Absent</option>
          <option value="retard">⚠️ Retard</option>
        </select>
      </td>
      <td><label style="cursor:pointer;display:flex;align-items:center;gap:8px;">
        <input type="checkbox" id="justif_${i}" style="accent-color:var(--accent);"> Justifiée
      </label></td>
    </tr>`).join('');
}

function saveAbsences(){
  let absents=0;
  students.forEach((s,i)=>{
    const v=document.getElementById('abs_'+i)?.value;
    if(v&&v!=='present')absents++;
  });
  showToast(`Absences enregistrées (${absents} absent(s)) !`,'success');
}

// Dashboard
document.getElementById('todayCours').innerHTML=`
  <div style="display:flex;flex-direction:column;gap:12px;">
  ${edtData.slice(0,2).map(e=>`
    <div style="display:flex;align-items:center;gap:12px;padding:10px;background:rgba(139,26,26,0.1);border-radius:10px;border:1px solid rgba(139,26,26,0.2);">
      <div style="background:linear-gradient(135deg,#8B1A1A,#C0392B);border-radius:8px;padding:8px;font-size:20px;">📚</div>
      <div><div style="font-size:14px;font-weight:600;color:var(--text-primary);">${e.cours}</div>
      <div style="font-size:12px;color:var(--text-muted);">${e.jour} · ${e.debut}–${e.fin} · ${e.salle}</div>
      <div style="font-size:12px;color:var(--gold);">Classe: ${e.classe}</div></div>
    </div>`).join('')}
  </div>`;

document.getElementById('absDate').valueAsDate=new Date();
setTimeout(()=>{ drawBarChart('chartClasses',['GL3-A BD','GL3-B PHP','GL3-A UML','GL3-B UML'],[14.2,15.6,13.8,14.9],'#1a4080'); },200);
</script>
</body>
</html>
