<?php
// ══════════════════════════════════════════════════
//  CONFIGURATION BASE DE DONNÉES - UIYA
// ══════════════════════════════════════════════════
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'uiya_scolarite');
define('DB_PORT', 3306);
define('APP_URL', 'http://localhost/uiya');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Erreur BDD : ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime'=>7200,'path'=>'/','secure'=>false,'httponly'=>true,'samesite'=>'Strict']);
    session_start();
}

function isLoggedIn(): bool { return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']); }

function requireLogin(): void {
    if (!isLoggedIn()) {
        if (isAjax()) { http_response_code(401); die(json_encode(['success'=>false,'message'=>'Non authentifié'])); }
        header('Location: ' . APP_URL . '/index.html?error=session_expired'); exit;
    }
}

function requireRole(string ...$roles): void {
    requireLogin();
    if (!in_array($_SESSION['user_type'], $roles, true)) {
        if (isAjax()) { http_response_code(403); die(json_encode(['success'=>false,'message'=>'Accès refusé'])); }
        header('Location: ' . APP_URL . '/index.html?error=access_denied'); exit;
    }
}

function isAjax(): bool {
    return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])==='xmlhttprequest')
        || (isset($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'],'application/json'));
}

function sanitize(string $data): string { return htmlspecialchars(strip_tags(trim($data)),ENT_QUOTES,'UTF-8'); }

function jsonResponse(array $data, int $code=200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE); exit;
}

function getInput(): array {
    $json = file_get_contents('php://input');
    if ($json) { $data=json_decode($json,true); if(json_last_error()===JSON_ERROR_NONE) return $data; }
    return array_merge($_GET,$_POST);
}

function hashPassword(string $p): string { return password_hash($p, PASSWORD_BCRYPT, ['cost'=>12]); }

function verifyPassword(string $p, string $hash): bool {
    if (strlen($hash)===64) return hash('sha256',$p)===$hash;
    return password_verify($p,$hash);
}

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(200);exit;}
?>
