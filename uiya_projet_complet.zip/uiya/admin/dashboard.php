<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>UIYA — Tableau de Bord Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon">U</div>
    <div class="logo-text">
      <div class="name">UIYA</div>
      <div class="sub">Administration</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar">A</div>
    <div class="user-info">
      <div class="user-name">Administrateur</div>
      <div class="user-role">Super Admin</div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-title">Principal</div>
    <a class="nav-item active" data-page="dashboard" onclick="showPage('dashboard')">
      <span class="icon">📊</span> Tableau de bord
    </a>
    <div class="nav-section-title">Gestion</div>
    <a class="nav-item" data-page="utilisateurs" onclick="showPage('utilisateurs')">
      <span class="icon">👥</span> Utilisateurs
    </a>
    <a class="nav-item" data-page="filieres" onclick="showPage('filieres')">
      <span class="icon">🏛️</span> Filières
    </a>
    <a class="nav-item" data-page="classes" onclick="showPage('classes')">
      <span class="icon">🏫</span> Classes
    </a>
    <a class="nav-item" data-page="cours" onclick="showPage('cours')">
      <span class="icon">📚</span> Cours
    </a>
    <a class="nav-item" data-page="emplois" onclick="showPage('emplois')">
      <span class="icon">📅</span> Emplois du temps
    </a>
    <a class="nav-item" data-page="notes" onclick="showPage('notes')">
      <span class="icon">📝</span> Notes
    </a>
    <a class="nav-item" data-page="absences" onclick="showPage('absences')">
      <span class="icon">📋</span> Absences <span class="badge">3</span>
    </a>
    <div class="nav-section-title">Rapports</div>
    <a class="nav-item" data-page="statistiques" onclick="showPage('statistiques')">
      <span class="icon">📈</span> Statistiques
    </a>
  </nav>
  <div class="sidebar-footer">
    <a class="nav-item" href="../index.html">
      <span class="icon">🚪</span> Déconnexion
    </a>
  </div>
</aside>

<!-- MAIN -->
<div class="main-content">
  <header class="topbar">
    <div class="topbar-left">
      <button class="topbar-btn hamburger" onclick="toggleSidebar()">☰</button>
      <div>
        <div class="topbar-title" id="pageTitle">Tableau de bord</div>
        <div class="topbar-subtitle" id="pageSubtitle">Bienvenue, Administrateur</div>
      </div>
    </div>
    <div class="topbar-right">
      <div class="search-box">
        <span class="search-icon">🔍</span>
        <input type="text" id="globalSearch" placeholder="Rechercher...">
      </div>
      <a class="topbar-btn" title="Notifications">🔔</a>
      <a class="topbar-btn" href="../index.html" title="Déconnexion">🚪</a>
    </div>
  </header>

  <!-- PAGES -->
  <div class="page-content">

    <!-- ── DASHBOARD PAGE ── -->
    <div id="page-dashboard">
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon">🎓</div>
          <div class="stat-value" data-counter="487">487</div>
          <div class="stat-label">Étudiants inscrits</div>
          <div class="stat-change up">↑ +12 ce mois</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">👨‍🏫</div>
          <div class="stat-value" data-counter="42">42</div>
          <div class="stat-label">Enseignants</div>
          <div class="stat-change neutral">Stable</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">🏛️</div>
          <div class="stat-value" data-counter="8">8</div>
          <div class="stat-label">Filières actives</div>
          <div class="stat-change up">↑ +1 nouveau</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">🏫</div>
          <div class="stat-value" data-counter="24">24</div>
          <div class="stat-label">Classes</div>
          <div class="stat-change neutral">Stable</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">📚</div>
          <div class="stat-value" data-counter="96">96</div>
          <div class="stat-label">Cours programmés</div>
          <div class="stat-change up">↑ +5 ce semestre</div>
        </div>
      </div>

      <div class="grid-2 mb-28">
        <div class="card">
          <div class="card-header">
            <span class="card-title">📈 Inscriptions par filière</span>
          </div>
          <div class="card-body">
            <canvas id="chartFilieres" style="width:100%;height:200px;display:block;"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card-header">
            <span class="card-title">🍩 Répartition des utilisateurs</span>
          </div>
          <div class="card-body">
            <canvas id="chartUsers" style="width:100%;height:200px;display:block;"></canvas>
            <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;">
              <span class="badge badge-info">🎓 Étudiants</span>
              <span class="badge badge-success">👨‍🏫 Enseignants</span>
              <span class="badge badge-gold">👨‍💼 Responsables</span>
              <span class="badge badge-warning">👨‍👧 Parents</span>
            </div>
          </div>
        </div>
      </div>

      <div class="grid-2">
        <div class="card">
          <div class="card-header">
            <span class="card-title">🕐 Activités récentes</span>
          </div>
          <div class="card-body" style="padding:0;">
            <div id="activityList"></div>
          </div>
        </div>
        <div class="card">
          <div class="card-header">
            <span class="card-title">📢 Accès rapide</span>
          </div>
          <div class="card-body">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
              <button class="btn btn-outline" onclick="showPage('utilisateurs')">➕ Ajouter un utilisateur</button>
              <button class="btn btn-outline" onclick="showPage('classes')">🏫 Nouvelle classe</button>
              <button class="btn btn-outline" onclick="showPage('filieres')">🏛️ Nouvelle filière</button>
              <button class="btn btn-outline" onclick="showPage('cours')">📚 Nouveau cours</button>
              <button class="btn btn-outline" onclick="showPage('emplois')">📅 Emploi du temps</button>
              <button class="btn btn-outline" onclick="showPage('statistiques')">📈 Statistiques</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── UTILISATEURS PAGE ── -->
    <div id="page-utilisateurs" style="display:none;">
      <div class="flex-between mb-20">
        <div>
          <div class="topbar-title">Gestion des Utilisateurs</div>
          <div class="topbar-subtitle">Administrez tous les comptes du système</div>
        </div>
        <button class="btn btn-primary" onclick="openModal('modalAddUser')">➕ Ajouter un utilisateur</button>
      </div>

      <!-- Stats row -->
      <div class="stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:20px;">
        <div class="stat-card"><div class="stat-icon">👥</div><div class="stat-value" style="font-size:24px;" data-counter="581">581</div><div class="stat-label">Total</div></div>
        <div class="stat-card"><div class="stat-icon">🎓</div><div class="stat-value" style="font-size:24px;" data-counter="487">487</div><div class="stat-label">Étudiants</div></div>
        <div class="stat-card"><div class="stat-icon">👨‍🏫</div><div class="stat-value" style="font-size:24px;" data-counter="42">42</div><div class="stat-label">Enseignants</div></div>
        <div class="stat-card"><div class="stat-icon">👨‍💼</div><div class="stat-value" style="font-size:24px;" data-counter="8">8</div><div class="stat-label">Responsables</div></div>
        <div class="stat-card"><div class="stat-icon">👨‍👧</div><div class="stat-value" style="font-size:24px;" data-counter="44">44</div><div class="stat-label">Parents</div></div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="flex-center gap-8">
            <select class="form-control" id="filterRole" onchange="filterTable()" style="width:160px;padding:8px 12px;font-size:13px;">
              <option value="">Tous les rôles</option>
              <option value="administrateur">Administrateur</option>
              <option value="responsable">Responsable</option>
              <option value="enseignant">Enseignant</option>
              <option value="etudiant">Étudiant</option>
              <option value="parent">Parent</option>
            </select>
          </div>
          <div class="search-box">
            <span class="search-icon">🔍</span>
            <input type="text" id="searchUser" placeholder="Rechercher..." oninput="filterTable()">
          </div>
        </div>
        <div class="table-wrapper">
          <table id="userTable">
            <thead><tr>
              <th>Nom complet</th><th>Email</th><th>Rôle</th><th>Genre</th><th>Téléphone</th><th>Statut</th><th>Actions</th>
            </tr></thead>
            <tbody id="userTableBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── FILIERES PAGE ── -->
    <div id="page-filieres" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Gestion des Filières</div><div class="topbar-subtitle">Gérez les filières de l'université</div></div>
        <button class="btn btn-primary" onclick="openModal('modalAddFiliere')">➕ Nouvelle filière</button>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Liste des filières</span>
          <div class="search-box"><span class="search-icon">🔍</span><input type="text" id="searchFiliere" placeholder="Rechercher..." oninput="filterFiliere()"></div>
        </div>
        <div class="table-wrapper">
          <table><thead><tr><th>#</th><th>Code</th><th>Nom de la filière</th><th>Niveau</th><th>Responsable</th><th>Étudiants</th><th>Actions</th></tr></thead>
            <tbody id="filiereTableBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── CLASSES PAGE ── -->
    <div id="page-classes" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Gestion des Classes</div><div class="topbar-subtitle">Organisez les classes par filière</div></div>
        <button class="btn btn-primary" onclick="openModal('modalAddClasse')">➕ Nouvelle classe</button>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Liste des classes</span>
          <div class="search-box"><span class="search-icon">🔍</span><input type="text" id="searchClasse" placeholder="Rechercher..."></div>
        </div>
        <div class="table-wrapper">
          <table><thead><tr><th>#</th><th>Nom de la classe</th><th>Filière</th><th>Effectif</th><th>Actions</th></tr></thead>
            <tbody id="classeTableBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── COURS PAGE ── -->
    <div id="page-cours" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Gestion des Cours</div><div class="topbar-subtitle">Administrez le catalogue des cours</div></div>
        <button class="btn btn-primary" onclick="openModal('modalAddCours')">➕ Nouveau cours</button>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Liste des cours</span>
          <div class="search-box"><span class="search-icon">🔍</span><input type="text" id="searchCours" placeholder="Rechercher..." oninput="filterCours()"></div>
        </div>
        <div class="table-wrapper">
          <table><thead><tr><th>#</th><th>Intitulé</th><th>Matière</th><th>Filière</th><th>Enseignant</th><th>Salle</th><th>Actions</th></tr></thead>
            <tbody id="coursTableBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── EMPLOIS DU TEMPS PAGE ── -->
    <div id="page-emplois" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Emplois du Temps</div><div class="topbar-subtitle">Visualisez et gérez les plannings</div></div>
        <button class="btn btn-primary" onclick="openModal('modalAddEDT')">➕ Ajouter un créneau</button>
      </div>
      <div class="card mb-20">
        <div class="card-header">
          <span class="card-title">Filtrer</span>
          <div class="flex-center gap-8">
            <select class="form-control" id="edtFiliere" style="width:160px;padding:8px 12px;font-size:13px;" onchange="renderEDT()">
              <option value="">Toutes les filières</option>
            </select>
            <select class="form-control" id="edtClasse" style="width:140px;padding:8px 12px;font-size:13px;" onchange="renderEDT()">
              <option value="">Toutes les classes</option>
            </select>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table class="schedule-table" id="edtTable">
            <thead><tr>
              <th style="width:100px;">Horaire</th>
              <th>Lundi</th><th>Mardi</th><th>Mercredi</th><th>Jeudi</th><th>Vendredi</th><th>Samedi</th>
            </tr></thead>
            <tbody id="edtTableBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── NOTES PAGE ── -->
    <div id="page-notes" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Gestion des Notes</div><div class="topbar-subtitle">Consultez et gérez les évaluations</div></div>
        <button class="btn btn-primary" onclick="openModal('modalAddNote')">➕ Saisir une note</button>
      </div>
      <div class="card mb-20">
        <div class="card-header">
          <span class="card-title">Filtres</span>
          <div class="flex-center gap-8">
            <select class="form-control" style="width:150px;padding:8px;font-size:13px;" id="noteClasse" onchange="filterNotes()"><option value="">Toutes les classes</option></select>
            <select class="form-control" style="width:130px;padding:8px;font-size:13px;" id="noteTrimestre" onchange="filterNotes()">
              <option value="">Tous les trimestres</option>
              <option value="1">Trimestre 1</option>
              <option value="2">Trimestre 2</option>
              <option value="3">Trimestre 3</option>
            </select>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Étudiant</th><th>Cours</th><th>Matière</th><th>Note /20</th><th>Coeff.</th><th>Trimestre</th><th>Appréciation</th><th>Actions</th></tr></thead>
            <tbody id="notesTableBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── ABSENCES PAGE ── -->
    <div id="page-absences" style="display:none;">
      <div class="flex-between mb-20">
        <div><div class="topbar-title">Gestion des Absences</div><div class="topbar-subtitle">Suivi des présences et absences</div></div>
        <button class="btn btn-primary" onclick="openModal('modalAddAbsence')">➕ Enregistrer une absence</button>
      </div>
      <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px;">
        <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value" style="font-size:24px;color:#22c55e;">1248</div><div class="stat-label">Présences</div></div>
        <div class="stat-card"><div class="stat-icon">❌</div><div class="stat-value" style="font-size:24px;color:#ef4444;">87</div><div class="stat-label">Absences</div></div>
        <div class="stat-card"><div class="stat-icon">⚠️</div><div class="stat-value" style="font-size:24px;color:#eab308;">23</div><div class="stat-label">Non justifiées</div></div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table><thead><tr><th>Étudiant</th><th>Classe</th><th>Date</th><th>Cours</th><th>Statut</th><th>Justifiée</th><th>Actions</th></tr></thead>
            <tbody id="absencesTableBody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── STATISTIQUES PAGE ── -->
    <div id="page-statistiques" style="display:none;">
      <div class="topbar-title mb-20">Statistiques Générales</div>
      <div class="grid-3 mb-20">
        <div class="card">
          <div class="card-header"><span class="card-title">📊 Notes par matière</span></div>
          <div class="card-body"><canvas id="chartNotes" style="width:100%;height:200px;display:block;"></canvas></div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title">📅 Absences / mois</span></div>
          <div class="card-body"><canvas id="chartAbsences" style="width:100%;height:200px;display:block;"></canvas></div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title">🎓 Répartition niveaux</span></div>
          <div class="card-body"><canvas id="chartNiveaux" style="width:100%;height:200px;display:block;"></canvas></div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">📋 Taux de réussite par filière</span></div>
        <div class="card-body">
          <div id="successRates"></div>
        </div>
      </div>
    </div>

  </div><!-- /page-content -->
</div><!-- /main-content -->

<!-- ═══════════ MODALS ═══════════ -->

<!-- ADD USER -->
<div class="modal-overlay" id="modalAddUser">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">➕ Ajouter un utilisateur</span>
      <button class="modal-close" onclick="closeModal('modalAddUser')">✕</button>
    </div>
    <div class="modal-body">
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Nom</label><input type="text" class="form-control" id="addNom" placeholder="Nom de famille"></div>
        <div class="form-group"><label class="form-label">Prénoms</label><input type="text" class="form-control" id="addPrenoms" placeholder="Prénoms"></div>
      </div>
      <div class="form-group"><label class="form-label">Email</label><input type="email" class="form-control" id="addEmail" placeholder="email@uiya.ci"></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Rôle</label>
          <select class="form-control" id="addRole">
            <option value="etudiant">Étudiant</option>
            <option value="enseignant">Enseignant</option>
            <option value="responsable">Responsable</option>
            <option value="parent">Parent</option>
            <option value="administrateur">Administrateur</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Genre</label>
          <select class="form-control" id="addGenre"><option value="M">Masculin</option><option value="F">Féminin</option></select>
        </div>
      </div>
      <div class="form-group"><label class="form-label">Téléphone</label><input type="text" class="form-control" id="addTel" placeholder="+225 00 00 00 00"></div>
      <div class="form-group"><label class="form-label">Mot de passe</label><input type="password" class="form-control" id="addPass" placeholder="Mot de passe provisoire"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('modalAddUser')">Annuler</button>
      <button class="btn btn-primary" onclick="addUser()">✅ Enregistrer</button>
    </div>
  </div>
</div>

<!-- ADD FILIERE -->
<div class="modal-overlay" id="modalAddFiliere">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">🏛️ Nouvelle filière</span><button class="modal-close" onclick="closeModal('modalAddFiliere')">✕</button></div>
    <div class="modal-body">
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Code filière</label><input type="text" class="form-control" id="fCode" placeholder="Ex: GL"></div>
        <div class="form-group"><label class="form-label">Niveau</label>
          <select class="form-control" id="fNiveau"><option>Licence 1</option><option>Licence 2</option><option>Licence 3</option><option>Master 1</option><option>Master 2</option></select>
        </div>
      </div>
      <div class="form-group"><label class="form-label">Nom de la filière</label><input type="text" class="form-control" id="fNom" placeholder="Ex: Génie Logiciel"></div>
      <div class="form-group"><label class="form-label">Responsable</label>
        <select class="form-control" id="fResp"><option value="">-- Sélectionner un responsable --</option></select>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('modalAddFiliere')">Annuler</button>
      <button class="btn btn-primary" onclick="addFiliere()">✅ Créer la filière</button>
    </div>
  </div>
</div>

<!-- ADD CLASSE -->
<div class="modal-overlay" id="modalAddClasse">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">🏫 Nouvelle classe</span><button class="modal-close" onclick="closeModal('modalAddClasse')">✕</button></div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Nom de la classe</label><input type="text" class="form-control" id="cNom" placeholder="Ex: GL3-A"></div>
      <div class="form-group"><label class="form-label">Filière</label>
        <select class="form-control" id="cFiliere"><option value="">-- Choisir une filière --</option></select>
      </div>
      <div class="form-group"><label class="form-label">Effectif maximum</label><input type="number" class="form-control" id="cEffectif" placeholder="30" min="1" max="100"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('modalAddClasse')">Annuler</button>
      <button class="btn btn-primary" onclick="addClasse()">✅ Créer la classe</button>
    </div>
  </div>
</div>

<!-- ADD COURS -->
<div class="modal-overlay" id="modalAddCours">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">📚 Nouveau cours</span><button class="modal-close" onclick="closeModal('modalAddCours')">✕</button></div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Intitulé du cours</label><input type="text" class="form-control" id="coIntitule" placeholder="Ex: Développement Web PHP"></div>
      <div class="form-group"><label class="form-label">Matière</label><input type="text" class="form-control" id="coMatiere" placeholder="Ex: Programmation Web"></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Filière</label>
          <select class="form-control" id="coFiliere"><option value="">-- Filière --</option></select>
        </div>
        <div class="form-group"><label class="form-label">Enseignant</label>
          <select class="form-control" id="coEns"><option value="">-- Enseignant --</option></select>
        </div>
      </div>
      <div class="form-group"><label class="form-label">Salle</label><input type="text" class="form-control" id="coSalle" placeholder="Ex: Salle 101"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('modalAddCours')">Annuler</button>
      <button class="btn btn-primary" onclick="addCours()">✅ Créer le cours</button>
    </div>
  </div>
</div>

<!-- ADD EDT -->
<div class="modal-overlay" id="modalAddEDT">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">📅 Ajouter un créneau</span><button class="modal-close" onclick="closeModal('modalAddEDT')">✕</button></div>
    <div class="modal-body">
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Filière</label><select class="form-control" id="edtFil"><option value="">--</option></select></div>
        <div class="form-group"><label class="form-label">Classe</label><select class="form-control" id="edtCl"><option value="">--</option></select></div>
      </div>
      <div class="form-group"><label class="form-label">Cours</label><select class="form-control" id="edtCo"><option value="">--</option></select></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Jour</label>
          <select class="form-control" id="edtJour">
            <option>Lundi</option><option>Mardi</option><option>Mercredi</option><option>Jeudi</option><option>Vendredi</option><option>Samedi</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Salle</label><input type="text" class="form-control" id="edtSalle" placeholder="Salle 101"></div>
      </div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Heure début</label><input type="time" class="form-control" id="edtDebut" value="08:00"></div>
        <div class="form-group"><label class="form-label">Heure fin</label><input type="time" class="form-control" id="edtFin" value="10:00"></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('modalAddEDT')">Annuler</button>
      <button class="btn btn-primary" onclick="addEDT()">✅ Enregistrer</button>
    </div>
  </div>
</div>

<!-- ADD NOTE -->
<div class="modal-overlay" id="modalAddNote">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">📝 Saisir une note</span><button class="modal-close" onclick="closeModal('modalAddNote')">✕</button></div>
    <div class="modal-body">
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Classe</label><select class="form-control" id="nClasse"><option value="">--</option></select></div>
        <div class="form-group"><label class="form-label">Étudiant</label><select class="form-control" id="nEtu"><option value="">--</option></select></div>
      </div>
      <div class="form-group"><label class="form-label">Cours</label><select class="form-control" id="nCours"><option value="">--</option></select></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Note /20</label><input type="number" class="form-control" id="nValeur" min="0" max="20" step="0.25" placeholder="Ex: 14.5"></div>
        <div class="form-group"><label class="form-label">Coefficient</label><input type="number" class="form-control" id="nCoeff" min="1" max="5" value="1"></div>
      </div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Trimestre</label>
          <select class="form-control" id="nTrim"><option value="1">Trimestre 1</option><option value="2">Trimestre 2</option><option value="3">Trimestre 3</option></select>
        </div>
        <div class="form-group"><label class="form-label">Appréciation</label>
          <select class="form-control" id="nAppre">
            <option value="">Auto</option><option>Excellent</option><option>Très Bien</option><option>Bien</option><option>Assez Bien</option><option>Passable</option><option>Insuffisant</option>
          </select>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('modalAddNote')">Annuler</button>
      <button class="btn btn-primary" onclick="addNote()">✅ Enregistrer la note</button>
    </div>
  </div>
</div>

<!-- ADD ABSENCE -->
<div class="modal-overlay" id="modalAddAbsence">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">📋 Enregistrer une absence</span><button class="modal-close" onclick="closeModal('modalAddAbsence')">✕</button></div>
    <div class="modal-body">
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Classe</label><select class="form-control" id="abClasse"><option value="">--</option></select></div>
        <div class="form-group"><label class="form-label">Étudiant</label><select class="form-control" id="abEtu"><option value="">--</option></select></div>
      </div>
      <div class="form-group"><label class="form-label">Cours concerné</label><select class="form-control" id="abCours"><option value="">--</option></select></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Date</label><input type="date" class="form-control" id="abDate"></div>
        <div class="form-group"><label class="form-label">Statut</label>
          <select class="form-control" id="abStatut"><option value="absent">Absent</option><option value="retard">Retard</option></select>
        </div>
      </div>
      <div class="form-group">
        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;color:var(--text-secondary);font-size:14px;">
          <input type="checkbox" id="abJustif" style="accent-color:var(--accent);">
          Absence justifiée
        </label>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('modalAddAbsence')">Annuler</button>
      <button class="btn btn-primary" onclick="addAbsence()">✅ Enregistrer</button>
    </div>
  </div>
</div>

<script src="../js/app.js"></script>
<script>
// ════════════════════════════════════════
// DATA STORE (localStorage for demo)
// ════════════════════════════════════════
const DB = {
  get(k) { try { return JSON.parse(localStorage.getItem('uiya_'+k)) || []; } catch(e){ return []; } },
  set(k,v) { localStorage.setItem('uiya_'+k, JSON.stringify(v)); },
  init() {
    if(!localStorage.getItem('uiya_initialized')) {
      DB.set('users', [
        {id:1,nom:'DIALLO',prenoms:'Amadou',email:'admin@uiya.ci',role:'administrateur',genre:'M',tel:'+225 07 00 00 01',statut:'actif'},
        {id:2,nom:'KONE',prenoms:'Fatoumata',email:'resp.info@uiya.ci',role:'responsable',genre:'F',tel:'+225 07 00 00 02',statut:'actif'},
        {id:3,nom:'COULIBALY',prenoms:'Jean-Paul',email:'jp.coulibaly@uiya.ci',role:'enseignant',genre:'M',tel:'+225 07 00 00 03',statut:'actif'},
        {id:4,nom:'YAO',prenoms:'Adjoua Victoire',email:'yao.adjoua@uiya.ci',role:'etudiant',genre:'F',tel:'+225 07 00 00 04',statut:'actif'},
        {id:5,nom:'KANGA',prenoms:'Arsène',email:'kanga.arsene@uiya.ci',role:'parent',genre:'M',tel:'+225 07 00 00 05',statut:'actif'},
        {id:6,nom:'TRAORÉ',prenoms:'Ibrahim',email:'traore.i@uiya.ci',role:'etudiant',genre:'M',tel:'+225 07 00 00 06',statut:'actif'},
        {id:7,nom:'N\'GUESSAN',prenoms:'Marie',email:'nguessan.m@uiya.ci',role:'etudiant',genre:'F',tel:'+225 07 00 00 07',statut:'actif'},
      ]);
      DB.set('filieres', [
        {id:1,code:'GL',nom:'Génie Logiciel',niveau:'Licence 3',resp:'KONE Fatoumata',etudiants:45},
        {id:2,code:'GRH',nom:'Gestion des Ressources Humaines',niveau:'Master 1',resp:'—',etudiants:38},
        {id:3,code:'CM',nom:'Communication',niveau:'Licence 2',resp:'—',etudiants:52},
        {id:4,code:'FBA',nom:'Finance, Banque & Assurance',niveau:'Master 2',resp:'—',etudiants:29},
      ]);
      DB.set('classes', [
        {id:1,nom:'GL3-A',filiere:'Génie Logiciel',effectif:25},
        {id:2,nom:'GL3-B',filiere:'Génie Logiciel',effectif:20},
        {id:3,nom:'GRH-M1',filiere:'Gestion des RH',effectif:38},
        {id:4,nom:'CM-L2',filiere:'Communication',effectif:52},
      ]);
      DB.set('cours', [
        {id:1,intitule:'Conception de bases de données',matiere:'Base de Données',filiere:'Génie Logiciel',enseignant:'COULIBALY Jean-Paul',salle:'Salle 101'},
        {id:2,intitule:'Développement Web PHP',matiere:'Programmation Web',filiere:'Génie Logiciel',enseignant:'COULIBALY Jean-Paul',salle:'Salle 102'},
        {id:3,intitule:'UML & Modélisation',matiere:'Génie Logiciel',filiere:'Génie Logiciel',enseignant:'COULIBALY Jean-Paul',salle:'Salle 103'},
      ]);
      DB.set('edt', [
        {id:1,filiere:'GL',classe:'GL3-A',cours:'BD',enseignant:'COULIBALY JP',jour:'Lundi',debut:'08:00',fin:'10:00',salle:'S.101'},
        {id:2,filiere:'GL',classe:'GL3-A',cours:'PHP',enseignant:'COULIBALY JP',jour:'Mercredi',debut:'10:00',fin:'12:00',salle:'S.102'},
        {id:3,filiere:'GL',classe:'GL3-A',cours:'UML',enseignant:'COULIBALY JP',jour:'Vendredi',debut:'14:00',fin:'16:00',salle:'S.103'},
      ]);
      DB.set('notes', [
        {id:1,etudiant:'YAO Adjoua',classe:'GL3-A',cours:'Base de Données',matiere:'BD',valeur:14.5,coeff:3,trimestre:1,appreciation:'Assez Bien'},
        {id:2,etudiant:'YAO Adjoua',classe:'GL3-A',cours:'PHP',matiere:'Web',valeur:16,coeff:2,trimestre:1,appreciation:'Bien'},
        {id:3,etudiant:'TRAORÉ Ibrahim',classe:'GL3-A',cours:'Base de Données',matiere:'BD',valeur:12,coeff:3,trimestre:1,appreciation:'Passable'},
      ]);
      DB.set('absences', [
        {id:1,etudiant:'YAO Adjoua',classe:'GL3-A',date:'2024-01-06',cours:'PHP',statut:'absent',justifiee:false},
        {id:2,etudiant:'TRAORÉ Ibrahim',classe:'GL3-A',date:'2024-01-08',cours:'UML',statut:'retard',justifiee:true},
        {id:3,etudiant:'N\'GUESSAN Marie',classe:'CM-L2',date:'2024-01-10',cours:'Communication',statut:'absent',justifiee:false},
      ]);
      DB.set('activities', [
        {icon:'👤',text:'Nouvel étudiant YAO Adjoua inscrit',time:'Il y a 2h'},
        {icon:'📝',text:'Notes BD T1 saisies pour GL3-A',time:'Il y a 5h'},
        {icon:'📅',text:'Emploi du temps GL3 mis à jour',time:'Hier'},
        {icon:'🏛️',text:'Filière Communication créée',time:'Il y a 2j'},
        {icon:'👨‍🏫',text:'COULIBALY JP ajouté comme enseignant',time:'Il y a 3j'},
      ]);
      localStorage.setItem('uiya_initialized','1');
    }
  }
};

// ════════════════════════════════════════
// PAGE NAVIGATION
// ════════════════════════════════════════
const pages = ['dashboard','utilisateurs','filieres','classes','cours','emplois','notes','absences','statistiques'];
const pageTitles = {
  dashboard:'Tableau de bord',utilisateurs:'Gestion des Utilisateurs',
  filieres:'Gestion des Filières',classes:'Gestion des Classes',
  cours:'Gestion des Cours',emplois:'Emplois du Temps',
  notes:'Gestion des Notes',absences:'Gestion des Absences',
  statistiques:'Statistiques'
};

function showPage(page) {
  pages.forEach(p => {
    const el = document.getElementById('page-'+p);
    if(el) el.style.display = p===page ? '' : 'none';
  });
  document.getElementById('pageTitle').textContent = pageTitles[page] || page;
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page===page);
  });
  // Render page data
  if(page==='utilisateurs') renderUsers();
  if(page==='filieres') renderFilieres();
  if(page==='classes') renderClasses();
  if(page==='cours') renderCours();
  if(page==='emplois') renderEDT();
  if(page==='notes') renderNotes();
  if(page==='absences') renderAbsences();
  if(page==='statistiques') renderStats();
  document.querySelector('.sidebar')?.classList.remove('open');
}

// ════════════════════════════════════════
// RENDER FUNCTIONS
// ════════════════════════════════════════
function roleLabel(role) {
  const map = {administrateur:'🛡️ Admin',responsable:'👨‍💼 Resp.',enseignant:'👨‍🏫 Enseign.',etudiant:'🎓 Étudiant',parent:'👨‍👧 Parent'};
  return map[role]||role;
}
function roleBadge(role) {
  const map = {administrateur:'badge-danger',responsable:'badge-gold',enseignant:'badge-info',etudiant:'badge-success',parent:'badge-warning'};
  return `<span class="badge ${map[role]||''}">${roleLabel(role)}</span>`;
}
function noteColor(v){ return v>=14?'#22c55e':v>=10?'#eab308':'#ef4444'; }

function renderUsers() {
  const users = DB.get('users');
  const filter = document.getElementById('filterRole').value;
  const search = document.getElementById('searchUser').value.toLowerCase();
  const filtered = users.filter(u =>
    (!filter || u.role===filter) &&
    (!search || (u.nom+u.prenoms+u.email).toLowerCase().includes(search))
  );
  document.getElementById('userTableBody').innerHTML = filtered.length ? filtered.map(u=>`
    <tr>
      <td><div style="display:flex;align-items:center;gap:10px;">
        <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#8B1A1A,#D4AF37);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:white;flex-shrink:0;">${u.nom[0]}</div>
        <span>${u.nom} ${u.prenoms}</span>
      </div></td>
      <td>${u.email}</td><td>${roleBadge(u.role)}</td>
      <td>${u.genre==='M'?'♂ Homme':'♀ Femme'}</td><td>${u.tel||'—'}</td>
      <td><span class="badge badge-success">✓ Actif</span></td>
      <td><div style="display:flex;gap:6px;">
        <button class="btn btn-outline btn-sm" onclick="editUser(${u.id})">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="deleteUser(${u.id})">🗑️</button>
      </div></td>
    </tr>`).join('') : '<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">👥</div><p>Aucun utilisateur trouvé</p></div></td></tr>';
}

function filterTable() { renderUsers(); }

function renderFilieres() {
  const data = DB.get('filieres');
  const search = document.getElementById('searchFiliere')?.value.toLowerCase()||'';
  const filtered = data.filter(f => !search || (f.nom+f.code).toLowerCase().includes(search));
  document.getElementById('filiereTableBody').innerHTML = filtered.map((f,i)=>`
    <tr>
      <td>${i+1}</td>
      <td><span class="badge badge-gold">${f.code}</span></td>
      <td><strong style="color:var(--text-primary)">${f.nom}</strong></td>
      <td><span class="badge badge-info">${f.niveau}</span></td>
      <td>${f.resp||'—'}</td>
      <td><div class="flex-center gap-8"><div class="progress" style="width:80px;"><div class="progress-bar" style="width:${Math.min((f.etudiants/60)*100,100)}%;"></div></div><span>${f.etudiants}</span></div></td>
      <td><div style="display:flex;gap:6px;">
        <button class="btn btn-outline btn-sm" onclick="editFiliere(${f.id})">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="deleteFiliere(${f.id})">🗑️</button>
      </div></td>
    </tr>`).join('');
}

function filterFiliere() { renderFilieres(); }

function renderClasses() {
  const data = DB.get('classes');
  document.getElementById('classeTableBody').innerHTML = data.map((c,i)=>`
    <tr>
      <td>${i+1}</td>
      <td><strong style="color:var(--text-primary)">${c.nom}</strong></td>
      <td>${c.filiere}</td>
      <td><div class="flex-center gap-8"><div class="progress" style="width:80px;"><div class="progress-bar" style="width:${Math.min((c.effectif/50)*100,100)}%;"></div></div><span>${c.effectif} élèves</span></div></td>
      <td><div style="display:flex;gap:6px;">
        <button class="btn btn-outline btn-sm" onclick="editClasse(${c.id})">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="deleteClasse(${c.id})">🗑️</button>
      </div></td>
    </tr>`).join('');
}

function renderCours() {
  const data = DB.get('cours');
  const search = document.getElementById('searchCours')?.value.toLowerCase()||'';
  const filtered = data.filter(c => !search || (c.intitule+c.matiere).toLowerCase().includes(search));
  document.getElementById('coursTableBody').innerHTML = filtered.map((c,i)=>`
    <tr>
      <td>${i+1}</td>
      <td><strong style="color:var(--text-primary)">${c.intitule}</strong></td>
      <td><span class="badge badge-info">${c.matiere}</span></td>
      <td>${c.filiere}</td>
      <td>${c.enseignant}</td>
      <td>${c.salle||'—'}</td>
      <td><div style="display:flex;gap:6px;">
        <button class="btn btn-outline btn-sm" onclick="editCours(${c.id})">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="deleteCours(${c.id})">🗑️</button>
      </div></td>
    </tr>`).join('');
}

function filterCours() { renderCours(); }

function renderEDT() {
  const data = DB.get('edt');
  const jours = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
  const heures = ['07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00'];
  let html = '';
  heures.forEach((h,i) => {
    if(i>=heures.length-1) return;
    const hFin = heures[i+1];
    html += `<tr><td style="color:var(--text-muted);font-size:12px;white-space:nowrap;">${h}–${hFin}</td>`;
    jours.forEach(jour => {
      const slot = data.find(e => e.jour===jour && e.debut<=h && e.fin>=hFin);
      html += `<td style="padding:4px;">`;
      if(slot) html += `<div class="schedule-cell"><div class="subject">${slot.cours}</div><div class="teacher">${slot.enseignant}</div><div class="room">${slot.salle}</div></div>`;
      html += `</td>`;
    });
    html += '</tr>';
  });
  document.getElementById('edtTableBody').innerHTML = html;
}

function renderNotes() {
  const data = DB.get('notes');
  document.getElementById('notesTableBody').innerHTML = data.map(n=>`
    <tr>
      <td>${n.etudiant}</td><td>${n.cours}</td><td>${n.matiere}</td>
      <td><strong style="color:${noteColor(n.valeur)};font-size:16px;">${n.valeur}/20</strong></td>
      <td>${n.coeff}</td>
      <td><span class="badge badge-info">T${n.trimestre}</span></td>
      <td><span class="badge ${n.valeur>=14?'badge-success':n.valeur>=10?'badge-warning':'badge-danger'}">${n.appreciation}</span></td>
      <td><div style="display:flex;gap:6px;">
        <button class="btn btn-outline btn-sm" onclick="editNote(${n.id})">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="deleteNote(${n.id})">🗑️</button>
      </div></td>
    </tr>`).join('');
}

function filterNotes() { renderNotes(); }

function renderAbsences() {
  const data = DB.get('absences');
  document.getElementById('absencesTableBody').innerHTML = data.map(a=>`
    <tr>
      <td>${a.etudiant}</td><td>${a.classe}</td><td>${a.date}</td><td>${a.cours}</td>
      <td><span class="badge ${a.statut==='absent'?'badge-danger':'badge-warning'}">${a.statut==='absent'?'❌ Absent':'⚠️ Retard'}</span></td>
      <td><span class="badge ${a.justifiee?'badge-success':'badge-danger'}">${a.justifiee?'✓ Oui':'✗ Non'}</span></td>
      <td><div style="display:flex;gap:6px;">
        <button class="btn btn-outline btn-sm" onclick="toggleJustif(${a.id})">✅</button>
        <button class="btn btn-danger btn-sm" onclick="deleteAbsence(${a.id})">🗑️</button>
      </div></td>
    </tr>`).join('');
}

function renderStats() {
  setTimeout(()=>{
    drawBarChart('chartFilieres',['GL','GRH','CM','FBA','Droit','Éco'],[45,38,52,29,61,44]);
    drawDonutChart('chartUsers',['Étudiants','Enseignants','Responsables','Parents'],[487,42,8,44],['#3b82f6','#22c55e','#D4AF37','#f97316']);
    drawBarChart('chartNotes',['BD','Web','UML','Maths','Anglais'],[14.2,15.1,12.8,13.5,16.0],'#1a4080');
    drawBarChart('chartAbsences',['Sep','Oct','Nov','Déc','Jan','Fév'],[12,18,8,22,15,11],'#8B1A1A');
    drawDonutChart('chartNiveaux',['Licence 1','Licence 2','Licence 3','Master 1','Master 2'],[120,110,95,80,82],['#8B1A1A','#C0392B','#D4AF37','#3b82f6','#22c55e']);
  },100);

  const filieres = DB.get('filieres');
  document.getElementById('successRates').innerHTML = filieres.map(f=>{
    const rate = Math.floor(70+Math.random()*25);
    return `<div style="margin-bottom:14px;">
      <div class="flex-between" style="margin-bottom:6px;">
        <span style="font-size:13px;color:var(--text-secondary);">${f.nom}</span>
        <span style="font-size:13px;font-weight:600;color:${rate>=80?'#22c55e':rate>=60?'#eab308':'#ef4444'}">${rate}%</span>
      </div>
      <div class="progress"><div class="progress-bar" style="width:${rate}%;"></div></div>
    </div>`;
  }).join('');
}

function renderDashboard() {
  const activities = DB.get('activities');
  document.getElementById('activityList').innerHTML = activities.map(a=>`
    <div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid rgba(255,255,255,0.04);">
      <span style="font-size:20px;">${a.icon}</span>
      <div style="flex:1;"><div style="font-size:13px;color:var(--text-secondary);">${a.text}</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${a.time}</div></div>
    </div>`).join('');
  setTimeout(()=>{
    drawBarChart('chartFilieres',['GL','GRH','CM','FBA','Droit','Éco'],[45,38,52,29,61,44]);
    drawDonutChart('chartUsers',['Étudiants','Enseignants','Responsables','Parents'],[487,42,8,44],['#3b82f6','#22c55e','#D4AF37','#f97316']);
  },200);
}

// ════════════════════════════════════════
// CRUD OPERATIONS
// ════════════════════════════════════════
let nextId = { users:10, filieres:10, classes:10, cours:10, edt:10, notes:10, absences:10 };

function addUser() {
  const nom=document.getElementById('addNom').value.trim();
  const prenoms=document.getElementById('addPrenoms').value.trim();
  const email=document.getElementById('addEmail').value.trim();
  const role=document.getElementById('addRole').value;
  const genre=document.getElementById('addGenre').value;
  const tel=document.getElementById('addTel').value.trim();
  if(!nom||!prenoms||!email){showToast('Veuillez remplir tous les champs obligatoires','error');return;}
  const users=DB.get('users');
  if(users.find(u=>u.email===email)){showToast('Cet email existe déjà','error');return;}
  const id=Date.now();
  users.push({id,nom,prenoms,email,role,genre,tel,statut:'actif'});
  DB.set('users',users);
  closeModal('modalAddUser');
  renderUsers();
  // add to activity
  const acts=DB.get('activities');
  acts.unshift({icon:'👤',text:`Nouvel utilisateur ${nom} ${prenoms} ajouté`,time:'À l\'instant'});
  DB.set('activities',acts.slice(0,10));
  showToast(`✅ ${nom} ${prenoms} ajouté avec succès !`,'success');
  ['addNom','addPrenoms','addEmail','addTel','addPass'].forEach(id=>document.getElementById(id).value='');
}

function deleteUser(id) {
  confirmAction('Supprimer cet utilisateur ?',()=>{
    DB.set('users', DB.get('users').filter(u=>u.id!==id));
    renderUsers();
    showToast('Utilisateur supprimé','info');
  });
}

function editUser(id) {
  showToast('Fonctionnalité de modification disponible','info');
}

function addFiliere() {
  const code=document.getElementById('fCode').value.trim().toUpperCase();
  const nom=document.getElementById('fNom').value.trim();
  const niveau=document.getElementById('fNiveau').value;
  if(!code||!nom){showToast('Veuillez remplir tous les champs','error');return;}
  const data=DB.get('filieres');
  if(data.find(f=>f.code===code)){showToast('Ce code filière existe déjà','error');return;}
  data.push({id:Date.now(),code,nom,niveau,resp:'—',etudiants:0});
  DB.set('filieres',data);
  closeModal('modalAddFiliere');
  renderFilieres();
  showToast(`Filière "${nom}" créée avec succès !`,'success');
  ['fCode','fNom'].forEach(id=>document.getElementById(id).value='');
}

function deleteFiliere(id) {
  confirmAction('Supprimer cette filière ?',()=>{
    DB.set('filieres',DB.get('filieres').filter(f=>f.id!==id));
    renderFilieres();
    showToast('Filière supprimée','info');
  });
}

function editFiliere(id){ showToast('Mode édition activé','info'); }

function addClasse() {
  const nom=document.getElementById('cNom').value.trim();
  const filiere=document.getElementById('cFiliere').value;
  const effectif=parseInt(document.getElementById('cEffectif').value)||0;
  if(!nom||!filiere){showToast('Veuillez remplir tous les champs','error');return;}
  const data=DB.get('classes');
  if(data.find(c=>c.nom===nom)){showToast('Cette classe existe déjà','error');return;}
  data.push({id:Date.now(),nom,filiere,effectif});
  DB.set('classes',data);
  closeModal('modalAddClasse');
  renderClasses();
  showToast(`Classe "${nom}" créée !`,'success');
}

function deleteClasse(id){
  confirmAction('Supprimer cette classe ?',()=>{
    DB.set('classes',DB.get('classes').filter(c=>c.id!==id));
    renderClasses(); showToast('Classe supprimée','info');
  });
}
function editClasse(id){ showToast('Mode édition activé','info'); }

function addCours() {
  const intitule=document.getElementById('coIntitule').value.trim();
  const matiere=document.getElementById('coMatiere').value.trim();
  const filiere=document.getElementById('coFiliere').value;
  const enseignant=document.getElementById('coEns').value;
  const salle=document.getElementById('coSalle').value.trim();
  if(!intitule||!matiere){showToast('Veuillez remplir les champs obligatoires','error');return;}
  const data=DB.get('cours');
  data.push({id:Date.now(),intitule,matiere,filiere,enseignant,salle});
  DB.set('cours',data);
  closeModal('modalAddCours');
  renderCours();
  showToast(`Cours "${intitule}" créé !`,'success');
}

function deleteCours(id){
  confirmAction('Supprimer ce cours ?',()=>{
    DB.set('cours',DB.get('cours').filter(c=>c.id!==id));
    renderCours(); showToast('Cours supprimé','info');
  });
}
function editCours(id){ showToast('Mode édition activé','info'); }

function addEDT() {
  const filiere=document.getElementById('edtFil').value;
  const classe=document.getElementById('edtCl').value;
  const cours=document.getElementById('edtCo').value;
  const jour=document.getElementById('edtJour').value;
  const debut=document.getElementById('edtDebut').value;
  const fin=document.getElementById('edtFin').value;
  const salle=document.getElementById('edtSalle').value.trim();
  if(!jour||!debut||!fin){showToast('Veuillez remplir tous les champs','error');return;}
  if(debut>=fin){showToast('L\'heure de fin doit être après le début','error');return;}
  const data=DB.get('edt');
  data.push({id:Date.now(),filiere,classe,cours,enseignant:'—',jour,debut,fin,salle});
  DB.set('edt',data);
  closeModal('modalAddEDT');
  renderEDT();
  showToast('Créneau ajouté à l\'emploi du temps !','success');
}

function addNote() {
  const etudiant=document.getElementById('nEtu').value;
  const cours=document.getElementById('nCours').value;
  const valeur=parseFloat(document.getElementById('nValeur').value);
  const coeff=parseFloat(document.getElementById('nCoeff').value)||1;
  const trimestre=document.getElementById('nTrim').value;
  if(!etudiant||!cours||isNaN(valeur)){showToast('Veuillez remplir tous les champs','error');return;}
  if(valeur<0||valeur>20){showToast('La note doit être entre 0 et 20','error');return;}
  const appreciation=valeur>=16?'Très Bien':valeur>=14?'Bien':valeur>=12?'Assez Bien':valeur>=10?'Passable':'Insuffisant';
  const data=DB.get('notes');
  const classe=document.getElementById('nClasse').value;
  data.push({id:Date.now(),etudiant,classe,cours,matiere:cours,valeur,coeff,trimestre,appreciation});
  DB.set('notes',data);
  closeModal('modalAddNote');
  renderNotes();
  showToast(`Note ${valeur}/20 enregistrée pour ${etudiant} !`,'success');
}

function deleteNote(id){
  confirmAction('Supprimer cette note ?',()=>{
    DB.set('notes',DB.get('notes').filter(n=>n.id!==id));
    renderNotes(); showToast('Note supprimée','info');
  });
}
function editNote(id){ showToast('Mode édition activé','info'); }

function addAbsence() {
  const etudiant=document.getElementById('abEtu').value;
  const classe=document.getElementById('abClasse').value;
  const cours=document.getElementById('abCours').value;
  const date=document.getElementById('abDate').value;
  const statut=document.getElementById('abStatut').value;
  const justifiee=document.getElementById('abJustif').checked;
  if(!etudiant||!date){showToast('Veuillez remplir tous les champs','error');return;}
  const data=DB.get('absences');
  data.push({id:Date.now(),etudiant,classe,cours,date,statut,justifiee});
  DB.set('absences',data);
  closeModal('modalAddAbsence');
  renderAbsences();
  showToast('Absence enregistrée !','success');
}

function deleteAbsence(id){
  confirmAction('Supprimer cet enregistrement ?',()=>{
    DB.set('absences',DB.get('absences').filter(a=>a.id!==id));
    renderAbsences(); showToast('Absence supprimée','info');
  });
}

function toggleJustif(id){
  const data=DB.get('absences');
  const ab=data.find(a=>a.id===id);
  if(ab){ ab.justifiee=!ab.justifiee; DB.set('absences',data); renderAbsences(); showToast('Statut mis à jour','success'); }
}

// Populate select menus with current data
function populateSelects() {
  const filieres=DB.get('filieres');
  const classes=DB.get('classes');
  const cours=DB.get('cours');
  const users=DB.get('users');
  const enseignants=users.filter(u=>u.role==='enseignant');
  const responsables=users.filter(u=>u.role==='responsable');
  const etudiants=users.filter(u=>u.role==='etudiant');

  const fillSelect=(id,opts)=>{
    const el=document.getElementById(id); if(!el) return;
    const first=el.options[0].cloneNode(true);
    el.innerHTML=''; el.appendChild(first);
    opts.forEach(o=>{ const opt=document.createElement('option'); opt.value=o.v; opt.textContent=o.l; el.appendChild(opt); });
  };
  fillSelect('fResp',responsables.map(u=>({v:u.id,l:`${u.nom} ${u.prenoms}`})));
  fillSelect('cFiliere',filieres.map(f=>({v:f.id,l:f.nom})));
  fillSelect('coFiliere',filieres.map(f=>({v:f.id,l:f.nom})));
  fillSelect('coEns',enseignants.map(u=>({v:u.id,l:`${u.nom} ${u.prenoms}`})));
  fillSelect('edtFil',filieres.map(f=>({v:f.code,l:f.nom})));
  fillSelect('edtCl',classes.map(c=>({v:c.id,l:c.nom})));
  fillSelect('edtCo',cours.map(c=>({v:c.id,l:c.intitule})));
  fillSelect('nClasse',classes.map(c=>({v:c.nom,l:c.nom})));
  fillSelect('nEtu',etudiants.map(u=>({v:`${u.nom} ${u.prenoms}`,l:`${u.nom} ${u.prenoms}`})));
  fillSelect('nCours',cours.map(c=>({v:c.intitule,l:c.intitule})));
  fillSelect('abClasse',classes.map(c=>({v:c.nom,l:c.nom})));
  fillSelect('abEtu',etudiants.map(u=>({v:`${u.nom} ${u.prenoms}`,l:`${u.nom} ${u.prenoms}`})));
  fillSelect('abCours',cours.map(c=>({v:c.intitule,l:c.intitule})));
}

// ════════════════════════════════════════
// INIT
// ════════════════════════════════════════
DB.init();
renderDashboard();
populateSelects();
document.getElementById('abDate').valueAsDate = new Date();
</script>
</body>
</html>
