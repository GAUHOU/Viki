// ── UIYA App JS ──

// Toast notifications
function showToast(msg, type='info') {
  let container = document.querySelector('.toast-container');
  if(!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = {success:'✅', error:'❌', info:'ℹ️', warning:'⚠️'};
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span>${msg}</span>`;
  container.appendChild(toast);
  setTimeout(()=>toast.classList.add('show'),10);
  setTimeout(()=>{toast.classList.remove('show');setTimeout(()=>toast.remove(),300);},3500);
}

// Modal
function openModal(id) { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }

// Close modal on overlay click
document.addEventListener('click', e => {
  if(e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// Hamburger toggle
function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('open');
}

// Active nav
function setActiveNav(page) {
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === page);
  });
}

// Confirm dialog
function confirmAction(msg, cb) {
  if(window.confirm(msg)) cb();
}

// Simple table search
function tableSearch(inputId, tableId) {
  const input = document.getElementById(inputId);
  if(!input) return;
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    document.querySelectorAll(`#${tableId} tbody tr`).forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}

// Animated counter
function animateCounter(el) {
  const target = parseInt(el.dataset.target || el.textContent);
  let current = 0;
  const step = Math.ceil(target / 50);
  const timer = setInterval(()=>{
    current = Math.min(current+step, target);
    el.textContent = current;
    if(current >= target) clearInterval(timer);
  }, 30);
}

document.addEventListener('DOMContentLoaded', ()=>{
  document.querySelectorAll('[data-counter]').forEach(animateCounter);
});

// Progress bar animation
document.addEventListener('DOMContentLoaded', ()=>{
  document.querySelectorAll('.progress-bar').forEach(bar => {
    const w = bar.style.width;
    bar.style.width = '0';
    setTimeout(()=>bar.style.width=w, 300);
  });
});

// Chart helper (simple canvas bar chart)
function drawBarChart(canvasId, labels, data, color='#8B1A1A') {
  const canvas = document.getElementById(canvasId);
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width = canvas.offsetWidth;
  const H = canvas.height = canvas.offsetHeight || 200;
  const max = Math.max(...data, 1);
  const barW = (W - 40) / labels.length - 10;
  ctx.clearRect(0,0,W,H);

  // Grid lines
  ctx.strokeStyle = 'rgba(255,255,255,0.05)';
  ctx.lineWidth = 1;
  for(let i=0;i<5;i++){
    const y = H - 30 - (i/4)*(H-50);
    ctx.beginPath(); ctx.moveTo(30,y); ctx.lineTo(W-10,y); ctx.stroke();
    ctx.fillStyle='rgba(255,255,255,0.2)'; ctx.font='10px DM Sans';
    ctx.fillText(Math.round(max*i/4), 0, y+4);
  }

  labels.forEach((label,i) => {
    const x = 40 + i*(barW+10);
    const barH = ((data[i]||0)/max)*(H-50);
    const y = H-30-barH;
    // gradient
    const grad = ctx.createLinearGradient(0,y,0,H-30);
    grad.addColorStop(0,'#D4AF37'); grad.addColorStop(1,color);
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(x, y, barW, barH, 4);
    ctx.fill();
    // label
    ctx.fillStyle='rgba(255,255,255,0.4)'; ctx.font='10px DM Sans';
    ctx.textAlign='center';
    ctx.fillText(label, x+barW/2, H-14);
    // value
    ctx.fillStyle='rgba(255,255,255,0.7)';
    ctx.fillText(data[i], x+barW/2, y-6);
  });
}

function drawDonutChart(canvasId, labels, data, colors) {
  const canvas = document.getElementById(canvasId);
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width = canvas.offsetWidth;
  const H = canvas.height = 200;
  const cx = W/2, cy = H/2, r = Math.min(cx,cy)-20, ri = r*0.55;
  const total = data.reduce((a,b)=>a+b,0);
  let angle = -Math.PI/2;
  data.forEach((val,i) => {
    const slice = (val/total)*Math.PI*2;
    ctx.beginPath();
    ctx.moveTo(cx,cy);
    ctx.arc(cx,cy,r,angle,angle+slice);
    ctx.closePath();
    ctx.fillStyle = colors[i];
    ctx.fill();
    angle += slice;
  });
  // hole
  ctx.beginPath();
  ctx.arc(cx,cy,ri,0,Math.PI*2);
  ctx.fillStyle = '#161b27';
  ctx.fill();
  // center text
  ctx.fillStyle='rgba(255,255,255,0.8)'; ctx.font='bold 22px Playfair Display';
  ctx.textAlign='center'; ctx.fillText(total, cx, cy+4);
  ctx.fillStyle='rgba(255,255,255,0.3)'; ctx.font='10px DM Sans';
  ctx.fillText('Total', cx, cy+20);
}
